# RuthShell

Asistente CLI multimodal con entrada/salida por voz, OCR, y GPT desktop bridge.