from core import input_audio, output_audio, chatgpt_bridge, command_injector
from ui.launcher import start_ball_ui
import threading
import pyperclip
import time

def loop():
    for user_input in input_audio.transcribe_audio():
        print(f"User said: {user_input}")
        pyperclip.copy(user_input)
        time.sleep(5)
        gpt_output = chatgpt_bridge.get_response_from_chatgpt()
        print(f"GPT: {gpt_output}")
        if "```" in gpt_output:
            code = gpt_output.split("```")[1].strip()
            command_injector.inject_to_terminal(code)
        else:
            output_audio.speak(gpt_output)

if __name__ == "__main__":
    threading.Thread(target=start_ball_ui).start()
    loop()
