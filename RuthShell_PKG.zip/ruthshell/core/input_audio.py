import vosk, pyaudio, json

def transcribe_audio():
    model = vosk.Model("model")
    rec = vosk.KaldiRecognizer(model, 16000)
    mic = pyaudio.PyAudio().open(rate=16000, channels=1, format=pyaudio.paInt16, input=True)
    while True:
        data = mic.read(4000)
        if rec.AcceptWaveform(data):
            result = json.loads(rec.Result())
            yield result.get("text", "")
