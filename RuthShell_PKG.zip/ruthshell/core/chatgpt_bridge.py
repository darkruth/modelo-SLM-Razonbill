import pyperclip, time

def get_response_from_chatgpt():
    time.sleep(1)
    return pyperclip.paste()
