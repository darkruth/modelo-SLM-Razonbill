import time
import requests
from PIL import Image
import pytesseract
import pyttsx3
import os

def speak(text):
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()

def capture_and_ocr():
    os.system("scrot /tmp/screen.png")
    img = Image.open("/tmp/screen.png")
    text = pytesseract.image_to_string(img)
    return text.strip()

if __name__ == "__main__":
    print("[*] OCR feedback live activo...")
    while True:
        texto = capture_and_ocr()
        if texto:
            print(f"[OCR] {texto}")
            speak(texto)
        time.sleep(8)
