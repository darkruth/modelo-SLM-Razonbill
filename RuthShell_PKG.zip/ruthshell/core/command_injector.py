import subprocess

def inject_to_terminal(cmd: str):
    subprocess.run(["xdotool", "type", "--clearmodifiers", cmd])
    subprocess.run(["xdotool", "key", "Return"])
