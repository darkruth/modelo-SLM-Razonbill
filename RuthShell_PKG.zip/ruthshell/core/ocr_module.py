from PIL import Image
import pytesseract

def extract_text(path="/tmp/screen.png"):
    image = Image.open(path)
    return pytesseract.image_to_string(image)
