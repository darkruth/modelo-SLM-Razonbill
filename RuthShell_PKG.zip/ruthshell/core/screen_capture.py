import subprocess

def capture_screen():
    subprocess.run(["scrot", "/tmp/screen.png"])
