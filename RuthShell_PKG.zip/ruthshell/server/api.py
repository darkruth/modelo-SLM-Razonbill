from flask import Flask, jsonify
from core.ocr_module import extract_text

app = Flask(__name__)

@app.route("/ocr", methods=["GET"])
def get_ocr_text():
    return jsonify({"text": extract_text()})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5678)
