#!/bin/bash

echo "[+] Iniciando entorno VNC con Kitty terminal..."

# Variables
export DISPLAY=:1
RESOLUTION=1024x768

# Iniciar VNC
vncserver $DISPLAY -geometry $RESOLUTION -depth 24

# Abrir terminal en sesión VNC
xterm -display $DISPLAY -e kitty &

# Iniciar websockify (reemplazar ruta si se instala diferente)
websockify --web=/usr/share/novnc/ 6080 localhost:5901 &
echo "[+] VNC disponible en http://localhost:6080"
