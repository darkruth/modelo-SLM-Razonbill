import os

def setup_autostart():
    autostart_path = os.path.expanduser("~/.config/autostart")
    os.makedirs(autostart_path, exist_ok=True)
    with open(os.path.join(autostart_path, "ruthshell.desktop"), "w") as f:
        f.write("[Desktop Entry]\n"
                "Type=Application\n"
                "Exec=python3 /ruta/a/ruthshell/main.py\n"
                "Hidden=false\n"
                "NoDisplay=false\n"
                "X-GNOME-Autostart-enabled=true\n"
                "Name=RuthShell\n")
