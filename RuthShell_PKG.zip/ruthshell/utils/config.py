# Configuración general
CHATGPT_WAIT_TIME = 5
