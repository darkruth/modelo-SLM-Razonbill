import datetime

def log_event(message):
    with open("ruthshell.log", "a") as log:
        log.write(f"[{datetime.datetime.now()}] {message}\n")
