#!/bin/bash

echo "[+] Instalando dependencias del sistema..."
sudo pacman -Sy --noconfirm xdotool scrot tesseract espeak kitty xclip

echo "[+] Instalando dependencias de Python..."
pip install -r requirements.txt

echo "[+] Estableciendo permisos..."
chmod +x main.py

echo "[+] RuthShell listo para ejecutarse."
echo "Corre con: python3 main.py"
