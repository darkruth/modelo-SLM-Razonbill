from PyQt5.QtWidgets import QApplication, QLabel
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt

def start_ball_ui():
    app = QApplication([])
    label = QLabel()
    label.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
    label.setPixmap(QPixmap("ui/assets/ball.png").scaled(100, 100))
    label.move(1600, 900)
    label.show()
    app.exec_()
