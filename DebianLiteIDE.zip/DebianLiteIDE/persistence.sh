#!/bin/bash
# Sistema de persistencia para la distribución

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PERSIST_DIR="${SCRIPT_DIR}/persistence"
ROOTFS_DIR="${SCRIPT_DIR}/rootfs"

# Función para crear backup de archivos
backup_files() {
    echo "Realizando backup de archivos..."
    
    # Crear directorio de persistencia si no existe
    mkdir -p "${PERSIST_DIR}"
    
    # Crear backup de directorios importantes
    if [ -d "${ROOTFS_DIR}/home" ]; then
        echo "Guardando archivos de usuario..."
        mkdir -p "${PERSIST_DIR}/home"
        cp -a "${ROOTFS_DIR}/home/." "${PERSIST_DIR}/home/" 2>/dev/null || true
    fi
    
    if [ -d "${ROOTFS_DIR}/root" ]; then
        echo "Guardando archivos de root..."
        mkdir -p "${PERSIST_DIR}/root"
        cp -a "${ROOTFS_DIR}/root/." "${PERSIST_DIR}/root/" 2>/dev/null || true
    fi
    
    if [ -d "${ROOTFS_DIR}/opt/ai-assistant" ]; then
        echo "Guardando configuración del asistente IA..."
        mkdir -p "${PERSIST_DIR}/opt/ai-assistant"
        cp -a "${ROOTFS_DIR}/opt/ai-assistant/." "${PERSIST_DIR}/opt/ai-assistant/" 2>/dev/null || true
    fi
    
    # Guardar archivo de tema
    if [ -f "${ROOTFS_DIR}/etc/dracula-theme.sh" ]; then
        echo "Guardando tema..."
        mkdir -p "${PERSIST_DIR}/etc"
        cp -a "${ROOTFS_DIR}/etc/dracula-theme.sh" "${PERSIST_DIR}/etc/" 2>/dev/null || true
    fi
    
    # Guardar archivos de ayuda
    if [ -f "${SCRIPT_DIR}/ruth-help" ] && [ -f "${SCRIPT_DIR}/ruth-help.txt" ]; then
        echo "Guardando documentación de ayuda..."
        mkdir -p "${PERSIST_DIR}/usr/local/bin"
        cp -a "${SCRIPT_DIR}/ruth-help" "${PERSIST_DIR}/usr/local/bin/" 2>/dev/null || true
        cp -a "${SCRIPT_DIR}/ruth-help.txt" "${PERSIST_DIR}/" 2>/dev/null || true
    fi
    
    echo "Backup completado en ${PERSIST_DIR}"
}

# Función para restaurar archivos desde backup
restore_files() {
    echo "Restaurando archivos desde backup..."
    
    if [ ! -d "${PERSIST_DIR}" ]; then
        echo "No se encontró directorio de persistencia. No hay nada que restaurar."
        return
    fi
    
    # Restaurar archivos de usuario
    if [ -d "${PERSIST_DIR}/home" ]; then
        echo "Restaurando archivos de usuario..."
        mkdir -p "${ROOTFS_DIR}/home"
        cp -a "${PERSIST_DIR}/home/." "${ROOTFS_DIR}/home/" 2>/dev/null || true
    fi
    
    # Restaurar archivos de root
    if [ -d "${PERSIST_DIR}/root" ]; then
        echo "Restaurando archivos de root..."
        mkdir -p "${ROOTFS_DIR}/root"
        cp -a "${PERSIST_DIR}/root/." "${ROOTFS_DIR}/root/" 2>/dev/null || true
    fi
    
    # Restaurar configuración del asistente IA
    if [ -d "${PERSIST_DIR}/opt/ai-assistant" ]; then
        echo "Restaurando configuración del asistente IA..."
        mkdir -p "${ROOTFS_DIR}/opt/ai-assistant"
        cp -a "${PERSIST_DIR}/opt/ai-assistant/." "${ROOTFS_DIR}/opt/ai-assistant/" 2>/dev/null || true
    fi
    
    # Restaurar archivo de tema
    if [ -f "${PERSIST_DIR}/etc/dracula-theme.sh" ]; then
        echo "Restaurando tema..."
        mkdir -p "${ROOTFS_DIR}/etc"
        cp -a "${PERSIST_DIR}/etc/dracula-theme.sh" "${ROOTFS_DIR}/etc/" 2>/dev/null || true
    fi
    
    # Restaurar archivos de ayuda
    if [ -f "${PERSIST_DIR}/usr/local/bin/ruth-help" ] && [ -f "${PERSIST_DIR}/ruth-help.txt" ]; then
        echo "Restaurando documentación de ayuda..."
        mkdir -p "${ROOTFS_DIR}/usr/local/bin"
        cp -a "${PERSIST_DIR}/usr/local/bin/ruth-help" "${SCRIPT_DIR}/" 2>/dev/null || true
        cp -a "${PERSIST_DIR}/ruth-help.txt" "${SCRIPT_DIR}/" 2>/dev/null || true
        chmod +x "${SCRIPT_DIR}/ruth-help" 2>/dev/null || true
    flocal 
    echo "Restauración completada desde ${PERSIST_DIR}"
}

# Mostrar ayuda
show_help() {
    echo "Sistema de persistencia para la distribución Debian CLI minimalista"
    echo ""
    echo "Uso: $0 [opción]"
    echo ""
    echo "Opciones:"
    echo "  backup    - Crea un backup de los archivos de usuario y configuración"
    echo "  restore   - Restaura archivos previamente guardados"
    echo "  help      - Muestra esta ayuda"
    echo ""
}

# Comprobar argumentos
if [ "$#" -lt 1 ]; then
    show_help
    exit 1
fi

# Procesar comandos
case "$1" in
    backup)
        backup_files
        ;;
    restore)
        restore_files
        ;;
    help)
        show_help
        ;;
    *)
        echo "Opción no válida: $1"
        show_help
        exit 1
        ;;
esac

exit 0