#!/bin/bash
# Simulated Debian Environment - Interactive Shell

# Set up Distro-Ruth theme with Ninja background
if [ -f "./rootfs/etc/dracula-theme.sh" ]; then
    source "./rootfs/etc/dracula-theme.sh"
    # Set a more stylish prompt with Distro-Ruth colors
    export PS1="${PS1_COLOR_USER}ninja${PS1_COLOR_HOST}@distro-ruth${PS1_COLOR_RESET}:${PS1_COLOR_PATH}\w${PS1_COLOR_RESET}${PS1_COLOR_PROMPT}\$ ${PS1_COLOR_RESET}"
else
    # Fallback prompt if theme file is not found
    export PS1="distro-ruth:\w\$ "
fi

# Apply Xeon dark background effect to terminal (ANSI escape sequence)
echo -e "\033[48;5;16m\033[38;5;189m"  # Dark background with light text

# Ejecutar la animación de inicio del ninja si existe
if [ -f "./ninja-animation.sh" ]; then
    chmod +x ./ninja-animation.sh
    ./ninja-animation.sh
else
    clear
fi

# Display themed banner
echo -e "\033[38;5;141m=================================================\033[0m"
echo -e "\033[38;5;212mDistro-Ruth - Ninja Shadow Edition\033[0m"
echo -e "\033[38;5;141m=================================================\033[0m"
echo -e "\033[38;5;117mThis is a simulated environment designed to work"
echo -e "within Replit's limitations.\033[0m"
echo ""
echo -e "\033[38;5;84mAvailable commands:\033[0m"
echo -e "\033[38;5;141m  1. \033[38;5;117mnano\033[0m - simple text editor"
echo -e "\033[38;5;141m  2. \033[38;5;117mvscode-web\033[0m - start VSCode web IDE"
echo -e "\033[38;5;141m  3. \033[38;5;117marduino-web\033[0m - start Arduino web IDE"
echo -e "\033[38;5;141m  4. \033[38;5;117mai-assistant\033[0m - start AI programming assistant (OpenAI/Anthropic)"
echo -e "\033[38;5;141m  5. \033[38;5;117mollama-agent\033[0m - start AI code agent with local Ollama models"
echo -e "\033[38;5;141m  6. \033[38;5;117mphi3-agent\033[0m - start AI code agent with local Phi-3 Mini model"
echo -e "\033[38;5;141m  7. \033[38;5;117mexit\033[0m - exit this environment"
echo -e "\033[38;5;141m=================================================\033[0m"

# Function to execute the nano command
nano_command() {
    clear
    echo -e "\033[38;5;141m=================================${NC}"
    echo -e "\033[38;5;117mNano Editor - DraculaX Theme${NC}"
    echo -e "\033[38;5;141m=================================${NC}"
    echo 
    echo -e "\033[38;5;84mSimulated nano editor${NC}"
    echo -e "\033[38;5;189mThis is a placeholder for the real nano editor${NC}"
    echo -e "\033[38;5;212mPress Ctrl+C to exit${NC}"
    echo
    echo -e "\033[38;5;141m┌───────────────────────────────────────────┐${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  In a real environment, you would see     \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  a text editor with syntax highlighting.  \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m                                           \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  The DraculaX theme would provide:        \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  - Dark background with vibrant colors    \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  - Improved readability for code          \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  - Special highlighting for syntax        \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m└───────────────────────────────────────────┘${NC}"
    echo
    
    echo -e "\033[38;5;212mCommands: ^G Get Help  ^O Write Out  ^W Where Is  ^K Cut Text${NC}"
    echo -e "\033[38;5;212m         ^X Exit      ^J Justify    ^R Read File ^U Paste  ${NC}"
    
    read -p "$(echo -e "\033[38;5;84mPress Enter to return to the shell...\033[0m")"
    clear
}

# Function to execute the VSCode Web command
vscode_web_command() {
    clear
    echo -e "\033[38;5;141m=================================${NC}"
    echo -e "\033[38;5;117mVSCode Web IDE - DraculaX Theme${NC}"
    echo -e "\033[38;5;141m=================================${NC}"
    echo 
    echo -e "\033[38;5;84mStarting simulated VSCode Web...${NC}"
    echo -e "\033[38;5;189mIn a real environment, VSCode would be available at \033[38;5;212mhttp://localhost:5000${NC}"
    echo
    echo -e "\033[38;5;141m┌───────────────────────────────────────────┐${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  VS Code Features with DraculaX:          \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  - Code editing with syntax highlighting  \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  - File browser with tree view            \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  - Integrated terminal                    \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  - Extensions and plugins support         \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  - Git integration                        \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  - Debugging tools                        \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m└───────────────────────────────────────────┘${NC}"
    echo
    
    read -p "$(echo -e "\033[38;5;84mPress Enter to return to the shell...\033[0m")"
    clear
}

# Function to execute the Arduino Web IDE command
arduino_web_command() {
    clear
    echo -e "\033[38;5;141m=================================${NC}"
    echo -e "\033[38;5;117mArduino Web IDE - DraculaX Theme${NC}"
    echo -e "\033[38;5;141m=================================${NC}"
    echo 
    echo -e "\033[38;5;84mStarting simulated Arduino Web IDE...${NC}"
    echo -e "\033[38;5;189mIn a real environment, Arduino IDE would be available at \033[38;5;212mhttp://localhost:5000${NC}"
    echo
    echo -e "\033[38;5;141m┌───────────────────────────────────────────┐${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  Arduino IDE Features:                    \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  - Code editing for Arduino sketches      \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  - Board and port selection               \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  - Compile and upload functionality       \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  - Serial monitor with DraculaX colors    \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m│\033[38;5;189m  - Library management                     \033[38;5;141m│${NC}"
    echo -e "\033[38;5;141m└───────────────────────────────────────────┘${NC}"
    echo
    
    read -p "$(echo -e "\033[38;5;84mPress Enter to return to the shell...\033[0m")"
    clear
}

# Function to execute the AI assistant command
ai_assistant_command() {
    clear
    echo -e "\033[38;5;141m=================================${NC}"
    echo -e "\033[38;5;212mAI Programming Assistant${NC}"
    echo -e "\033[38;5;141m=================================${NC}"
    echo 
    echo -e "\033[38;5;189mType your questions below and press Enter to send.${NC}"
    echo -e "\033[38;5;189mType '\033[38;5;212mexit\033[38;5;189m' to quit the assistant.${NC}"
    echo

    # Simple interactive loop
    while true; do
        echo -e -n "\033[38;5;84mYou: \033[38;5;189m"
        read -r user_input
        
        if [ "$user_input" == "exit" ]; then
            echo -e "\033[38;5;212mGoodbye!${NC}"
            break
        fi
        
        echo
        echo -e "\033[38;5;141mAI: \033[38;5;189mThis is a simulated AI assistant response."
        echo -e "    In a real environment with an API key configured,"
        echo -e "    you would receive an actual AI-generated response here."
        echo -e "    To configure an API key, you would use: \033[38;5;212mai-assistant --set-key YOUR_API_KEY\033[38;5;189m"
        echo
    done
    clear
}

# Function to execute the Ollama assistant command
ollama_agent_command() {
    clear
    echo -e "\033[38;5;141m=================================${NC}"
    echo -e "\033[38;5;212mOllama AI Code Agent${NC}"
    echo -e "\033[38;5;141m=================================${NC}"
    echo 
    echo -e "\033[38;5;117mAsistente de IA local con modelos Ollama${NC}"
    echo -e "\033[38;5;189mEste asistente ejecuta modelos de lenguaje localmente${NC}"
    echo -e "\033[38;5;189msin necesidad de API keys o conexión a internet.${NC}"
    echo
    
    if [ -x "./ai-assistant/ollama-agent" ]; then
        # Check if we're in a container where Ollama can't run
        if [ -f "/.dockerenv" ] || grep -q 'container=lxc' /proc/1/environ 2>/dev/null; then
            echo -e "\033[38;5;203mEstás ejecutando Distro-Ruth en un entorno containerizado (Replit).${NC}"
            echo -e "\033[38;5;203mOllama no puede ejecutarse en este entorno.${NC}"
            echo -e "\033[38;5;189mEn un entorno local (Linux/Mac), Ollama funcionaría normalmente.${NC}"
            echo
            echo -e "\033[38;5;141m┌───────────────────────────────────────────┐${NC}"
            echo -e "\033[38;5;141m│\033[38;5;189m  Opciones disponibles en Ollama:           \033[38;5;141m│${NC}"
            echo -e "\033[38;5;141m│\033[38;5;189m  - Modelos de código como Llama 3 y Code   \033[38;5;141m│${NC}"
            echo -e "\033[38;5;141m│\033[38;5;189m  - Sin límites de tokens o costos          \033[38;5;141m│${NC}"
            echo -e "\033[38;5;141m│\033[38;5;189m  - Funcionamiento sin conexión a Internet  \033[38;5;141m│${NC}"
            echo -e "\033[38;5;141m│\033[38;5;189m  - Mayor privacidad de datos               \033[38;5;141m│${NC}"
            echo -e "\033[38;5;141m└───────────────────────────────────────────┘${NC}"
            echo
        else
            # In a local environment, execute the real agent
            ./ai-assistant/ollama-agent
            
            # After exiting the real agent
            clear
            return
        fi
    else
        echo -e "\033[38;5;203mNo se encontró el agente Ollama.${NC}"
        echo -e "\033[38;5;189mVerifique la instalación.${NC}"
    fi
    
    # For simulated mode only
    echo -e "\033[38;5;189mPresiona Enter para regresar al shell principal.${NC}"
    read
    clear
}

# Function to execute the Phi-3 assistant command
phi3_agent_command() {
    clear
    echo -e "\033[38;5;141m=================================${NC}"
    echo -e "\033[38;5;212mPhi-3 Mini AI Code Agent${NC}"
    echo -e "\033[38;5;141m=================================${NC}"
    echo 
    echo -e "\033[38;5;117mAsistente de IA local con el modelo Phi-3 Mini${NC}"
    echo -e "\033[38;5;189mEste asistente ejecuta el modelo Phi-3 de Microsoft localmente${NC}"
    echo -e "\033[38;5;189msin necesidad de API keys o conexión a internet.${NC}"
    echo
    
    # Check if we're in a container where local LLMs can't run well
    if [ -f "/.dockerenv" ] || grep -q 'container=lxc' /proc/1/environ 2>/dev/null; then
        echo -e "\033[38;5;203mEstás ejecutando Distro-Ruth en un entorno containerizado (Replit).${NC}"
        echo -e "\033[38;5;203mLos LLM locales tienen limitaciones en este entorno.${NC}"
        echo -e "\033[38;5;189mEn un entorno local (Linux/Mac), Phi-3 funcionaría correctamente.${NC}"
        echo
        echo -e "\033[38;5;141m┌───────────────────────────────────────────┐${NC}"
        echo -e "\033[38;5;141m│\033[38;5;189m  Características de Phi-3 Mini:            \033[38;5;141m│${NC}"
        echo -e "\033[38;5;141m│\033[38;5;189m  - Modelo ligero optimizado para código    \033[38;5;141m│${NC}"
        echo -e "\033[38;5;141m│\033[38;5;189m  - Inferencia rápida en CPU                \033[38;5;141m│${NC}"
        echo -e "\033[38;5;141m│\033[38;5;189m  - Funciona 100% sin conexión              \033[38;5;141m│${NC}"
        echo -e "\033[38;5;141m│\033[38;5;189m  - Desarrollado por Microsoft Research     \033[38;5;141m│${NC}"
        echo -e "\033[38;5;141m└───────────────────────────────────────────┘${NC}"
        echo
        
        echo -e "\033[38;5;212m¿Deseas instalar Phi-3 en esta distro? (s/n)${NC}"
        read -r response
        
        if [[ "$response" == "s" || "$response" == "S" ]]; then
            if [ -f "./ai-assistant/distro-setup-phi3.sh" ]; then
                chmod +x ./ai-assistant/distro-setup-phi3.sh
                ./ai-assistant/distro-setup-phi3.sh
            else
                echo -e "\033[38;5;203mNo se encontró el script de instalación.${NC}"
            fi
        fi
    else
        # In a local environment, check if model exists
        if [ -f "./run-phi3.sh" ]; then
            chmod +x ./run-phi3.sh
            ./run-phi3.sh
        elif [ -f "./ai-assistant/phi3-agent" ]; then
            chmod +x ./ai-assistant/phi3-agent
            ./ai-assistant/phi3-agent
        else
            echo -e "\033[38;5;203mNo se encontró el modelo Phi-3 instalado.${NC}"
            echo -e "\033[38;5;117m¿Deseas instalarlo ahora? (s/n)${NC}"
            read -r response
            
            if [[ "$response" == "s" || "$response" == "S" ]]; then
                if [ -f "./ai-assistant/distro-setup-phi3.sh" ]; then
                    chmod +x ./ai-assistant/distro-setup-phi3.sh
                    ./ai-assistant/distro-setup-phi3.sh
                else
                    echo -e "\033[38;5;203mNo se encontró el script de instalación.${NC}"
                fi
            fi
        fi
        
        # After exiting the real agent
        clear
        return
    fi
    
    # For simulated mode only
    echo -e "\033[38;5;189mPresiona Enter para regresar al shell principal.${NC}"
    read
    clear
}

# Main interactive loop
while true; do
    echo -n "$PS1 "
    read -r command args
    
    case "$command" in
        "nano")
            nano_command
            ;;
        "vscode-web")
            vscode_web_command
            ;;
        "arduino-web")
            arduino_web_command
            ;;
        "ai-assistant")
            ai_assistant_command
            ;;
        "ollama-agent")
            ollama_agent_command
            ;;
        "phi3-agent")
            phi3_agent_command
            ;;
        "ruth-help")
            if [ -f "./ruth-help" ]; then
                chmod +x ./ruth-help
                ./ruth-help
            elif [ -f "./rootfs/usr/local/bin/ruth-help" ]; then
                chmod +x ./rootfs/usr/local/bin/ruth-help
                ./rootfs/usr/local/bin/ruth-help
            else
                echo -e "\033[38;5;203mNo se encontró el archivo de ayuda ruth-help.${NC}"
                echo -e "\033[38;5;117mEjecuta ./setup.sh para reinstalar componentes.${NC}"
            fi
            ;;
        "ls")
            echo -e "\033[38;5;141mbin  \033[38;5;117mdev  \033[38;5;212metc  \033[38;5;141mhome  \033[38;5;117mlib64  \033[38;5;212mopt  \033[38;5;141mproc  \033[38;5;117mroot  \033[38;5;212msbin  \033[38;5;141msys  \033[38;5;117mtmp  \033[38;5;212musr  \033[38;5;141mvar\033[0m"
            ;;
        "cd")
            echo -e "\033[38;5;117mCambiando directorio a \033[38;5;212m$args\033[38;5;117m (simulado)\033[0m"
            ;;
        "pwd")
            echo -e "\033[38;5;212m/root\033[0m"
            ;;
        "cat")
            echo -e "\033[38;5;141m┌───────────────────────────────────────────┐\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;189m  Contenido simulado del archivo: \033[38;5;212m$args  \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;189m  En un entorno real, verías el contenido    \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;189m  del archivo con resaltado de sintaxis.     \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m└───────────────────────────────────────────┘\033[0m"
            ;;
        "exit")
            echo -e "\033[38;5;117mRealizando backup antes de salir...\033[0m"
            if [ -f "./persistence.sh" ]; then
                chmod +x ./persistence.sh
                ./persistence.sh backup
            fi
            echo -e "\033[38;5;212mSaliendo del entorno Debian CLI...\033[0m"
            # Reset terminal colors before exit
            echo -e "\033[0m"
            clear
            exit 0
            ;;
        "help")
            echo -e "\033[38;5;141m┌───────────────────────────────────────────────────────┐\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;212m          Comandos disponibles - DraculaX Theme         \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m├───────────────────────┬───────────────────────────────┤\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;117m  Herramientas        \033[38;5;141m│\033[38;5;189m Comandos del sistema          \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m├───────────────────────┼───────────────────────────────┤\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;84m  nano                \033[38;5;141m│\033[38;5;189m Editor de texto simple        \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;84m  vscode-web          \033[38;5;141m│\033[38;5;189m IDE Visual Studio Code       \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;84m  arduino-web         \033[38;5;141m│\033[38;5;189m IDE para Arduino             \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;84m  ai-assistant        \033[38;5;141m│\033[38;5;189m Asistente de programación IA \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;84m  ollama-agent        \033[38;5;141m│\033[38;5;189m Asistente de código con Ollama \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;84m  phi3-agent          \033[38;5;141m│\033[38;5;189m Asistente de código con Phi-3 \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;84m  ruth-help           \033[38;5;141m│\033[38;5;189m Guía completa de comandos     \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m├───────────────────────┼───────────────────────────────┤\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;117m  Sistema             \033[38;5;141m│\033[38;5;189m                              \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m├───────────────────────┼───────────────────────────────┤\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;84m  ls                  \033[38;5;141m│\033[38;5;189m Listar archivos              \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;84m  cd                  \033[38;5;141m│\033[38;5;189m Cambiar directorio           \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;84m  pwd                 \033[38;5;141m│\033[38;5;189m Mostrar directorio actual    \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;84m  cat                 \033[38;5;141m│\033[38;5;189m Mostrar contenido de archivo \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;84m  help                \033[38;5;141m│\033[38;5;189m Mostrar esta ayuda           \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m│\033[38;5;84m  exit                \033[38;5;141m│\033[38;5;189m Salir del entorno            \033[38;5;141m│\033[0m"
            echo -e "\033[38;5;141m└───────────────────────┴───────────────────────────────┘\033[0m"
            ;;
        "")
            # Do nothing for empty input
            ;;
        *)
            echo "Command not found: $command. Type 'help' for available commands."
            ;;
    esac
done
