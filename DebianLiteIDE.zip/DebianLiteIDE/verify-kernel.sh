
#!/bin/bash

# Colores
GREEN='\033[0;32m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

echo "=== Verificación de la Integridad del Kernel y Shell ==="

# Verificar shell en rootfs
SHELL_EXEC="./rootfs/bin/bash"
if [ -x "$SHELL_EXEC" ]; then
    echo -e "${GREEN}Shell encontrado en rootfs: ${SHELL_EXEC}${NC}"
else
    echo -e "${RED}El shell no se encuentra en rootfs${NC}"
fi

# Comprobar versión de kernel
echo -e "\n${BLUE}>>> Información del Kernel:${NC}"
uname -a

# Verificar sistema de archivos rootfs
echo -e "\n${BLUE}>>> Verificando sistema de archivos rootfs:${NC}"
if [ -d "./rootfs" ]; then
    echo -e "${GREEN}Sistema de archivos rootfs presente${NC}"
    ls -l ./rootfs/bin/ | grep -E "bash|sh"
else
    echo -e "${RED}No se encuentra el directorio rootfs${NC}"
fi

# Verificar binarios esenciales
echo -e "\n${BLUE}>>> Verificando binarios esenciales:${NC}"
BINS=("ls" "cp" "rm" "mkdir" "touch" "cat")
for bin in "${BINS[@]}"; do
    if [ -x "./rootfs/bin/$bin" ]; then
        echo -e "${GREEN}✓ $bin${NC}"
    else
        echo -e "${RED}✗ $bin${NC}"
    fi
done
