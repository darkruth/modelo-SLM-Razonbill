#!/bin/bash
# Minimalist Debian CLI Environment Simulation
# Setup script

set -e

# Colores para la consola
PURPLE='\033[38;5;141m'
PINK='\033[38;5;212m'
BLUE='\033[38;5;117m'
GREEN='\033[38;5;84m'
YELLOW='\033[38;5;228m'
RED='\033[38;5;203m'
RESET='\033[0m'

# Display banner
echo -e "${PURPLE}==================================================${RESET}"
echo -e "${PINK}          Configurando Distro-Ruth              ${RESET}"
echo -e "${BLUE}  con Herramientas de Desarrollo y Asistente IA ${RESET}"
echo -e "${PURPLE}==================================================${RESET}"

# Create reference structure for the simulation
echo -e "${GREEN}Creando estructura de referencia del entorno...${RESET}"

# Create rootfs directory for reference
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$SCRIPT_DIR/rootfs"

# Copy AI assistant files to the expected location 
echo -e "${GREEN}Configurando el asistente IA...${RESET}"
mkdir -p "$SCRIPT_DIR/rootfs/opt/ai-assistant"
cp -r "$SCRIPT_DIR/ai-assistant/"* "$SCRIPT_DIR/rootfs/opt/ai-assistant/" 2>/dev/null || true

# Check if Ollama is installed and install if not
echo -e "${GREEN}Comprobando instalación de Ollama...${RESET}"

# A function to check if we're running in a suitable environment for Ollama
check_ollama_environment() {
  # Check if we're in a container environment that might not support Ollama
  if [ -f "/.dockerenv" ] || grep -q 'container=lxc' /proc/1/environ 2>/dev/null; then
    echo -e "${YELLOW}Detectado entorno containerizado. Ollama podría no funcionar correctamente.${RESET}"
    echo -e "${YELLOW}La funcionalidad del agente de IA será simulada.${RESET}"
    return 1
  fi
  return 0
}

# In Replit, we can't actually install Ollama, so we'll just simulate it
if check_ollama_environment; then
  echo -e "${BLUE}Entorno compatible con Ollama detectado.${RESET}"
  echo -e "${BLUE}Nota: En entornos reales, aquí se instalaría Ollama automáticamente.${RESET}"
  echo -e "${BLUE}Para usar el asistente IA, instale Ollama manualmente desde https://ollama.com${RESET}"
else
  echo -e "${YELLOW}Creando ambiente simulado para Ollama...${RESET}"
fi

# Ensure Ollama agent is executable
chmod +x "$SCRIPT_DIR/ai-assistant/ollama-agent"

# Configurar el comando ruth-help
echo -e "${GREEN}Configurando el comando ruth-help...${RESET}"
# Asegurar que el script ruth-help sea ejecutable
if [ -f "$SCRIPT_DIR/ruth-help" ]; then
    chmod +x "$SCRIPT_DIR/ruth-help"
    # Crear enlace simbólico en /usr/local/bin si estamos en un entorno real
    # O copiarlo al directorio rootfs para la simulación
    mkdir -p "$SCRIPT_DIR/rootfs/usr/local/bin"
    cp "$SCRIPT_DIR/ruth-help" "$SCRIPT_DIR/rootfs/usr/local/bin/"
    cp "$SCRIPT_DIR/ruth-help.txt" "$SCRIPT_DIR/rootfs/"
    echo -e "${BLUE}Comando ruth-help instalado correctamente.${RESET}"
else
    echo -e "${YELLOW}Advertencia: No se encontró el archivo ruth-help.${RESET}"
fi

# Restaurar datos desde persistencia si existen
if [ -f "./persistence.sh" ]; then
    echo "Comprobando datos de persistencia..."
    chmod +x ./persistence.sh
    ./persistence.sh restore
fi

echo "================================================="
echo "Setup completed successfully!"
echo "Run './start.sh' to enter the simulated environment."
echo "To backup your files, run './persistence.sh backup'"
echo "================================================="
