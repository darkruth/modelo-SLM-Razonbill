#!/usr/bin/env python3
"""
Ollama AI Code Agent for Distro-Ruth
This module provides the functionality for the AI programming assistant using Ollama.
It allows running LLMs locally without requiring external API keys.
"""

import os
import sys
import json
import curses
import textwrap
import time
from datetime import datetime
import threading
import re
import argparse
import requests
import subprocess

# Constants
CONFIG_DIR = os.path.expanduser("~/.config/distro-ruth")
CONFIG_FILE = os.path.join(CONFIG_DIR, "ollama-config.json")
CHAT_HISTORY_FILE = os.path.join(CONFIG_DIR, "ollama-chat-history.json")

# Ollama defaults
OLLAMA_ENDPOINT = "http://localhost:11434"
DEFAULT_MODEL = "llama3"  # Default model - lightweight version
AVAILABLE_MODELS = ["llama3", "llama3:8b", "gemma:2b", "mistral", "codellama", "phi3"]

# UI Settings
MAX_WIDTH = 100  # Max width for text display
INPUT_HEIGHT = 3  # Height of input area


class OllamaAgent:
    """Main class for interacting with Ollama LLM"""
    
    def __init__(self, model=DEFAULT_MODEL):
        """Initialize Ollama agent with specified model"""
        self.model = model
        self.chat_history = []
        self.ollama_installed = False
        
        # Ensure config directory exists
        if not os.path.exists(CONFIG_DIR):
            os.makedirs(CONFIG_DIR)
        
        # Load configuration
        self.load_config()
        
        # Check if Ollama is installed and running
        self.check_ollama()
    
    def load_config(self):
        """Load configuration from config file"""
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, 'r') as f:
                    config = json.load(f)
                    
                    # Load model name if available
                    if "model" in config:
                        self.model = config["model"]
                    
                    # Load chat history if available
                    if os.path.exists(CHAT_HISTORY_FILE):
                        with open(CHAT_HISTORY_FILE, 'r') as hf:
                            self.chat_history = json.load(hf)
            except (json.JSONDecodeError, IOError) as e:
                print(f"Error loading configuration: {e}")
    
    def save_config(self):
        """Save configuration to config file"""
        config = {
            "model": self.model
        }
        
        try:
            with open(CONFIG_FILE, 'w') as f:
                json.dump(config, f)
        except IOError as e:
            print(f"Error saving configuration: {e}")
    
    def save_chat_history(self):
        """Save chat history to file"""
        try:
            with open(CHAT_HISTORY_FILE, 'w') as f:
                json.dump(self.chat_history, f)
        except IOError as e:
            print(f"Error saving chat history: {e}")
    
    def check_ollama(self):
        """Check if Ollama is installed and accessible"""
        try:
            # Check if Ollama is installed
            result = subprocess.run(['which', 'ollama'], 
                                    stdout=subprocess.PIPE, 
                                    stderr=subprocess.PIPE)
            
            if result.returncode == 0:
                self.ollama_installed = True
                # Check if Ollama server is running
                try:
                    response = requests.get(f"{OLLAMA_ENDPOINT}/api/version")
                    if response.status_code == 200:
                        return True
                except requests.RequestException:
                    return False
            return False
        except Exception:
            return False
    
    def start_ollama_server(self):
        """Start the Ollama server if it's not already running"""
        if not self.ollama_installed:
            return "Ollama is not installed. Please install Ollama first."
        
        try:
            # Start Ollama server as a background process
            subprocess.Popen(['ollama', 'serve'], 
                             stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE)
            
            # Wait a bit for the server to start
            time.sleep(2)
            
            # Check if server is now running
            try:
                response = requests.get(f"{OLLAMA_ENDPOINT}/api/version")
                if response.status_code == 200:
                    return "Ollama server started successfully."
            except requests.RequestException:
                pass
            
            return "Failed to start Ollama server. Please start it manually with 'ollama serve'."
        except Exception as e:
            return f"Error starting Ollama server: {str(e)}"
    
    def list_available_models(self):
        """List models available locally in Ollama"""
        if not self.check_ollama():
            return "Ollama server is not running. Please start it with 'ollama serve'."
        
        try:
            response = requests.get(f"{OLLAMA_ENDPOINT}/api/tags")
            if response.status_code == 200:
                models = response.json().get('models', [])
                return [model['name'] for model in models]
            return []
        except requests.RequestException:
            return []
    
    def pull_model(self, model_name):
        """Pull a model from Ollama registry"""
        if not self.check_ollama():
            return "Ollama server is not running. Please start it with 'ollama serve'."
        
        try:
            # This is a non-blocking progress report
            def check_progress():
                while True:
                    try:
                        cmd = subprocess.run(['ollama', 'list'], 
                                        stdout=subprocess.PIPE, 
                                        stderr=subprocess.PIPE,
                                        text=True)
                        if model_name in cmd.stdout:
                            break
                        time.sleep(1)
                    except Exception:
                        break
            
            # Start the pull process
            subprocess.Popen(['ollama', 'pull', model_name], 
                             stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE)
            
            # Start checking progress in a separate thread
            threading.Thread(target=check_progress).start()
            
            return f"Pulling model {model_name}. This may take a while..."
        except Exception as e:
            return f"Error pulling model: {str(e)}"
    
    def generate_response(self, user_message, system_prompt=None, streaming=True):
        """Generate a response from Ollama"""
        if not self.check_ollama():
            return "Ollama server is not running. Please start it with 'ollama serve'."
        
        # Add message to history
        self.chat_history.append({
            "role": "user",
            "content": user_message,
            "timestamp": datetime.now().isoformat()
        })
        
        # Default system prompt for code agent
        if system_prompt is None:
            system_prompt = (
                "You are an expert coding assistant built into the Distro-Ruth CLI environment. "
                "Your primary purpose is to help with programming tasks, explain code, and provide "
                "technical solutions. When providing code, use syntax highlighting and follow best practices. "
                "Be concise but thorough, and include explanations with your code. "
                "For questions about the CLI, explain commands and interface features clearly."
            )
        
        # Prepare messages for the API
        messages = []
        for msg in self.chat_history[-10:]:  # Limit to last 10 messages
            messages.append({
                "role": msg["role"],
                "content": msg["content"]
            })
        
        # Prepare the API payload
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": streaming,
            "options": {
                "temperature": 0.7,
                "num_predict": 1024
            }
        }
        
        if system_prompt:
            payload["system"] = system_prompt
        
        try:
            if streaming:
                response_chunks = []
                response = requests.post(
                    f"{OLLAMA_ENDPOINT}/api/chat",
                    json=payload,
                    stream=True
                )
                
                for line in response.iter_lines():
                    if line:
                        try:
                            chunk_data = json.loads(line)
                            if "message" in chunk_data and "content" in chunk_data["message"]:
                                response_chunks.append(chunk_data["message"]["content"])
                                yield chunk_data["message"]["content"]
                            
                            # Check if it's the final message
                            if "done" in chunk_data and chunk_data["done"]:
                                break
                        except json.JSONDecodeError:
                            continue
                
                # Save full response to history
                full_response = "".join(response_chunks)
                self.chat_history.append({
                    "role": "assistant",
                    "content": full_response,
                    "timestamp": datetime.now().isoformat()
                })
                self.save_chat_history()
            else:
                response = requests.post(
                    f"{OLLAMA_ENDPOINT}/api/chat",
                    json=payload
                )
                
                if response.status_code == 200:
                    response_data = response.json()
                    response_text = response_data.get("message", {}).get("content", "")
                    
                    # Save to history
                    self.chat_history.append({
                        "role": "assistant",
                        "content": response_text,
                        "timestamp": datetime.now().isoformat()
                    })
                    self.save_chat_history()
                    
                    return response_text
                else:
                    return f"Error: {response.status_code} - {response.text}"
        
        except Exception as e:
            return f"Error generating response: {str(e)}"


class TerminalUI:
    """Terminal User Interface for the Ollama Agent"""
    
    def __init__(self, stdscr, ollama_agent):
        """Initialize the terminal UI with the specified Ollama agent"""
        self.stdscr = stdscr
        self.ollama_agent = ollama_agent
        
        # Initialize curses
        curses.curs_set(1)  # Show cursor
        curses.use_default_colors()
        curses.start_color()
        
        # Initialize color pairs
        self.init_colors()
        
        # Window dimensions
        self.height, self.width = stdscr.getmaxyx()
        
        # Input buffer
        self.input_buffer = ""
        self.cursor_pos = 0
        
        # Chat display buffer
        self.chat_display = []
        
        # Scroll position
        self.scroll_pos = 0
        
        # Load chat history
        self.load_chat_history()
    
    def init_colors(self):
        """Initialize color pairs for the UI"""
        # Base colors for DraculaX theme
        curses.init_pair(1, 141, -1)  # Purple for UI elements
        curses.init_pair(2, 212, -1)  # Pink for highlights
        curses.init_pair(3, 117, -1)  # Light blue for user input
        curses.init_pair(4, 84, -1)   # Green for system messages
        curses.init_pair(5, 228, -1)  # Yellow for warnings
        curses.init_pair(6, 203, -1)  # Red for errors
        curses.init_pair(7, 255, -1)  # White for normal text
        
        # Color definitions
        self.COLOR_HEADER = curses.color_pair(1)
        self.COLOR_HIGHLIGHT = curses.color_pair(2)
        self.COLOR_USER = curses.color_pair(3)
        self.COLOR_SYSTEM = curses.color_pair(4)
        self.COLOR_WARNING = curses.color_pair(5)
        self.COLOR_ERROR = curses.color_pair(6)
        self.COLOR_NORMAL = curses.color_pair(7)
    
    def load_chat_history(self):
        """Load chat history from the Ollama agent"""
        for msg in self.ollama_agent.chat_history:
            self.chat_display.append({
                "role": msg["role"],
                "content": msg["content"].splitlines()
            })
    
    def resize(self):
        """Handle terminal resize event"""
        self.height, self.width = self.stdscr.getmaxyx()
        self.stdscr.clear()
        self.update_display()
    
    def draw_header(self):
        """Draw the header bar"""
        # Calculate centered title
        title = "Distro-Ruth Ollama Code Agent"
        x = max(0, (self.width - len(title)) // 2)
        
        # Draw top border
        self.stdscr.addstr(0, 0, "═" * self.width, self.COLOR_HEADER)
        
        # Draw title
        self.stdscr.addstr(1, x, title, self.COLOR_HIGHLIGHT | curses.A_BOLD)
        
        # Draw model info
        model_info = f"Model: {self.ollama_agent.model}"
        self.stdscr.addstr(1, 2, model_info, self.COLOR_SYSTEM)
        
        # Draw bottom border
        self.stdscr.addstr(2, 0, "═" * self.width, self.COLOR_HEADER)
    
    def draw_footer(self):
        """Draw the footer with instructions"""
        footer_y = self.height - 2
        
        # Draw top border
        self.stdscr.addstr(footer_y - 1, 0, "═" * self.width, self.COLOR_HEADER)
        
        # Draw instructions
        instructions = "Ctrl+C: Exit | Up/Down: Scroll | Enter: Send | Tab: Code Block"
        x = max(0, (self.width - len(instructions)) // 2)
        self.stdscr.addstr(footer_y, x, instructions, self.COLOR_SYSTEM)
    
    def draw_input_area(self):
        """Draw the input area where the user types"""
        input_start_y = self.height - 3 - INPUT_HEIGHT
        
        # Draw border
        self.stdscr.addstr(input_start_y, 0, "╔" + "═" * (self.width - 2) + "╗", self.COLOR_HEADER)
        for i in range(INPUT_HEIGHT):
            self.stdscr.addstr(input_start_y + 1 + i, 0, "║", self.COLOR_HEADER)
            self.stdscr.addstr(input_start_y + 1 + i, self.width - 1, "║", self.COLOR_HEADER)
        self.stdscr.addstr(input_start_y + 1 + INPUT_HEIGHT, 0, "╚" + "═" * (self.width - 2) + "╝", self.COLOR_HEADER)
        
        # Draw prompt
        prompt = "You: "
        self.stdscr.addstr(input_start_y + 1, 2, prompt, self.COLOR_USER | curses.A_BOLD)
        
        # Calculate visible part of input buffer
        prompt_len = len(prompt) + 2  # +2 for padding
        visible_width = self.width - prompt_len - 3
        
        # Ensure cursor is in visible area
        if self.cursor_pos < 0:
            self.cursor_pos = 0
        elif self.cursor_pos > len(self.input_buffer):
            self.cursor_pos = len(self.input_buffer)
        
        # Display buffer with word wrap
        y_offset = 0
        x_offset = prompt_len
        
        # Simple word wrap for input
        buffer_lines = textwrap.wrap(self.input_buffer, width=visible_width) if self.input_buffer else [""]
        for i, line in enumerate(buffer_lines[:INPUT_HEIGHT]):
            if i < INPUT_HEIGHT:
                self.stdscr.addstr(input_start_y + 1 + i, prompt_len if i == 0 else 2, line, self.COLOR_NORMAL)
        
        # Position cursor
        cursor_x = prompt_len + self.cursor_pos
        cursor_y = input_start_y + 1
        
        # Adjust for word wrap
        while cursor_x >= self.width - 2:
            cursor_x -= (self.width - 4)
            cursor_y += 1
        
        self.stdscr.move(cursor_y, cursor_x)
    
    def draw_chat_history(self):
        """Draw the chat history"""
        chat_start_y = 3  # Start after header
        chat_height = self.height - 3 - INPUT_HEIGHT - 4  # Space for chat
        
        # Clear the chat area
        for i in range(chat_height):
            self.stdscr.addstr(chat_start_y + i, 0, " " * self.width)
        
        # Calculate how many messages to display
        displayable_messages = []
        current_y = 0
        
        # Go through messages from newest to oldest until we fill the screen
        for msg in reversed(self.chat_display):
            role = msg["role"]
            content_lines = msg["content"]
            
            # Calculate height of this message
            msg_height = len(content_lines) + 1  # +1 for the role indicator
            
            # Add message to displayable list if it fits
            if current_y + msg_height <= chat_height:
                displayable_messages.insert(0, msg)
                current_y += msg_height + 1  # +1 for spacing
            else:
                # If we're scrolled, keep adding older messages
                if self.scroll_pos > 0:
                    self.scroll_pos -= 1
                else:
                    break
        
        # Display messages
        current_y = chat_start_y
        for msg in displayable_messages:
            role = msg["role"]
            content_lines = msg["content"]
            
            # Display role with appropriate color
            role_text = "You: " if role == "user" else "AI: "
            role_color = self.COLOR_USER if role == "user" else self.COLOR_HIGHLIGHT
            self.stdscr.addstr(current_y, 2, role_text, role_color | curses.A_BOLD)
            current_y += 1
            
            # Display message content with proper formatting
            for line in content_lines:
                # Handle code blocks with syntax highlighting
                if line.strip().startswith("```"):
                    self.stdscr.addstr(current_y, 4, line, self.COLOR_SYSTEM)
                elif line.strip().startswith("`") and line.strip().endswith("`"):
                    self.stdscr.addstr(current_y, 4, line, self.COLOR_HIGHLIGHT)
                else:
                    self.stdscr.addstr(current_y, 4, line[:self.width-6], self.COLOR_NORMAL)
                
                current_y += 1
            
            # Add spacing between messages
            current_y += 1
            
            # Stop if we've reached the bottom of the chat area
            if current_y >= chat_start_y + chat_height:
                break
    
    def update_display(self):
        """Update the entire display"""
        self.stdscr.clear()
        self.draw_header()
        self.draw_chat_history()
        self.draw_input_area()
        self.draw_footer()
        self.stdscr.refresh()
    
    def insert_text(self, text):
        """Insert text at cursor position"""
        before = self.input_buffer[:self.cursor_pos]
        after = self.input_buffer[self.cursor_pos:]
        self.input_buffer = before + text + after
        self.cursor_pos += len(text)
    
    def send_message(self):
        """Send the current input buffer as a message to Ollama"""
        if not self.input_buffer.strip():
            return
        
        # Get the user message
        user_message = self.input_buffer.strip()
        
        # Clear the input buffer
        self.input_buffer = ""
        self.cursor_pos = 0
        
        # Add user message to chat display
        self.chat_display.append({
            "role": "user",
            "content": user_message.splitlines()
        })
        
        # Update the display
        self.update_display()
        
        # Create a thread for the Ollama response to avoid blocking the UI
        def get_ollama_response():
            # Add a placeholder for the Ollama response
            ai_msg_idx = len(self.chat_display)
            self.chat_display.append({
                "role": "assistant",
                "content": ["Thinking..."]
            })
            self.update_display()
            
            # Buffer for collecting the full response
            full_response = []
            current_line = ""
            
            # Get streaming response
            for chunk in self.ollama_agent.generate_response(user_message, streaming=True):
                # Append to the current line
                current_line += chunk
                
                # Handle newlines in chunks
                if '\n' in current_line:
                    lines = current_line.split('\n')
                    for i in range(len(lines) - 1):
                        full_response.append(lines[i])
                    current_line = lines[-1]
                
                # Update display with current progress
                self.chat_display[ai_msg_idx] = {
                    "role": "assistant",
                    "content": full_response + [current_line]
                }
                self.update_display()
                time.sleep(0.01)  # Small delay to avoid screen flicker
            
            # Add final line if not empty
            if current_line:
                full_response.append(current_line)
            
            # Update with the complete response
            self.chat_display[ai_msg_idx] = {
                "role": "assistant",
                "content": full_response
            }
            self.update_display()
        
        # Start the response thread
        threading.Thread(target=get_ollama_response).start()
    
    def handle_key(self, key):
        """Process a single keystroke"""
        if key == curses.KEY_RESIZE:
            self.resize()
        
        elif key in (curses.KEY_ENTER, 10, 13):  # Enter key
            self.send_message()
        
        elif key == curses.KEY_BACKSPACE or key == 127:  # Backspace
            if self.cursor_pos > 0:
                self.input_buffer = self.input_buffer[:self.cursor_pos-1] + self.input_buffer[self.cursor_pos:]
                self.cursor_pos -= 1
        
        elif key == curses.KEY_DC:  # Delete key
            if self.cursor_pos < len(self.input_buffer):
                self.input_buffer = self.input_buffer[:self.cursor_pos] + self.input_buffer[self.cursor_pos+1:]
        
        elif key == curses.KEY_LEFT:  # Left arrow
            if self.cursor_pos > 0:
                self.cursor_pos -= 1
        
        elif key == curses.KEY_RIGHT:  # Right arrow
            if self.cursor_pos < len(self.input_buffer):
                self.cursor_pos += 1
        
        elif key == curses.KEY_UP:  # Up arrow - scroll chat history
            self.scroll_pos += 1
        
        elif key == curses.KEY_DOWN:  # Down arrow - scroll chat history
            if self.scroll_pos > 0:
                self.scroll_pos -= 1
        
        elif key == 9:  # Tab key - insert code block marker
            self.insert_text("```\n\n```")
            self.cursor_pos -= 4  # Position cursor inside the code block
        
        elif key == 24:  # Ctrl+X - clear buffer
            self.input_buffer = ""
            self.cursor_pos = 0
        
        elif 32 <= key <= 126:  # Printable ASCII characters
            self.insert_text(chr(key))
        
        self.update_display()
    
    def run(self):
        """Main loop for the chat interface"""
        # Initial update
        self.update_display()
        
        # Main loop
        while True:
            try:
                key = self.stdscr.getch()
                
                # Exit on Ctrl+C
                if key == 3:
                    break
                
                self.handle_key(key)
            
            except KeyboardInterrupt:
                break
            except Exception as e:
                # Log error and continue
                with open(os.path.join(CONFIG_DIR, "error.log"), "a") as f:
                    f.write(f"{datetime.now().isoformat()}: {str(e)}\n")
                continue


def setup_ollama():
    """Setup and start Ollama if needed"""
    agent = OllamaAgent()
    
    # Check if Ollama is installed
    if not agent.ollama_installed:
        print("Ollama is not installed. Installing...")
        
        try:
            # Try to install Ollama
            subprocess.run(['curl', '-fsSL', 'https://ollama.com/install.sh', '-o', '/tmp/install.sh'], 
                           stdout=subprocess.PIPE, 
                           stderr=subprocess.PIPE)
            
            subprocess.run(['chmod', '+x', '/tmp/install.sh'], 
                           stdout=subprocess.PIPE, 
                           stderr=subprocess.PIPE)
            
            subprocess.run(['/tmp/install.sh'], 
                           stdout=subprocess.PIPE, 
                           stderr=subprocess.PIPE)
            
            print("Ollama installed successfully.")
        except Exception as e:
            print(f"Failed to install Ollama: {e}")
            print("Please install Ollama manually from https://ollama.com/download")
            return False
    
    # Check if Ollama server is running
    if not agent.check_ollama():
        print("Starting Ollama server...")
        result = agent.start_ollama_server()
        print(result)
        
        if "successfully" not in result:
            print("Please start Ollama manually with 'ollama serve'")
            return False
    
    # Check if default model is available
    available_models = agent.list_available_models()
    if agent.model not in available_models:
        print(f"Downloading {agent.model} model... This may take a while.")
        agent.pull_model(agent.model)
    
    return True


def main_ui(stdscr):
    """Main function to initialize and run the terminal UI"""
    # Create Ollama agent
    ollama_agent = OllamaAgent()
    
    # Create and run UI
    ui = TerminalUI(stdscr, ollama_agent)
    ui.run()


def command_line_interface():
    """Handle command-line arguments for the Ollama assistant"""
    parser = argparse.ArgumentParser(description="Distro-Ruth Ollama Code Agent")
    parser.add_argument("--setup", action="store_true", help="Setup Ollama and download default model")
    parser.add_argument("--set-model", help="Set the Ollama model to use")
    parser.add_argument("--list-models", action="store_true", help="List available Ollama models")
    parser.add_argument("--pull-model", help="Download a model from Ollama registry")
    parser.add_argument("--query", help="Single query mode: ask a question and exit")
    
    args = parser.parse_args()
    
    # Create Ollama agent
    ollama_agent = OllamaAgent()
    
    # Handle setup
    if args.setup:
        setup_ollama()
        return
    
    # Handle model setting
    if args.set_model:
        ollama_agent.model = args.set_model
        ollama_agent.save_config()
        print(f"Now using {args.set_model} as the Ollama model.")
        return
    
    # Handle model listing
    if args.list_models:
        models = ollama_agent.list_available_models()
        if models:
            print("Available Ollama models:")
            for model in models:
                print(f"  - {model}")
        else:
            print("No models available or Ollama server is not running.")
        return
    
    # Handle model pulling
    if args.pull_model:
        result = ollama_agent.pull_model(args.pull_model)
        print(result)
        return
    
    # Handle single query mode
    if args.query:
        print(f"Query: {args.query}")
        print("\nThinking...\n")
        
        response = ollama_agent.generate_response(args.query, streaming=False)
        print("Response:\n")
        print(response)
        return
    
    # Check if Ollama is running
    if not ollama_agent.check_ollama():
        print("Ollama server is not running. Please set it up first:")
        print("  ollama-agent --setup")
        return
    
    # Launch interactive UI
    try:
        curses.wrapper(main_ui)
    except Exception as e:
        print(f"Error in UI: {e}")
        with open(os.path.join(CONFIG_DIR, "error.log"), "a") as f:
            f.write(f"{datetime.now().isoformat()}: {str(e)}\n")


if __name__ == "__main__":
    command_line_interface()