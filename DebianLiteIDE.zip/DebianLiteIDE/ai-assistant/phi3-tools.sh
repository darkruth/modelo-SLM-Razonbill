#!/bin/bash
# Herramientas para el agente Phi-3 Mini
# Este script proporciona funciones para que el agente Phi-3 
# pueda interactuar con el sistema Distro-Ruth

# Colores para la consola
PURPLE='\033[38;5;141m'
PINK='\033[38;5;212m'
BLUE='\033[38;5;117m'
GREEN='\033[38;5;84m'
YELLOW='\033[38;5;228m'
RED='\033[38;5;203m'
RESET='\033[0m'

# Directorio base
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$BASE_DIR/.." && pwd)"
TOOLS_LOG="$ROOT_DIR/.phi3-tools.log"

# Función para registrar acciones en el log
log_action() {
    local action="$1"
    local details="$2"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $action: $details" >> "$TOOLS_LOG"
}

# Función para ejecutar comandos del sistema
execute_command() {
    local cmd="$1"
    local log_output="$2"
    
    log_action "EJECUTAR" "$cmd"
    
    # Verificar si el comando es potencialmente peligroso
    if [[ "$cmd" == *"rm -rf"* || "$cmd" == *"mkfs"* || "$cmd" == *":(){:"* || "$cmd" == *"dd if=/dev/zero"* ]]; then
        echo -e "${RED}Comando potencialmente peligroso detectado. No se ejecutará:${RESET}"
        echo -e "${YELLOW}$cmd${RESET}"
        log_action "ADVERTENCIA" "Comando peligroso bloqueado: $cmd"
        return 1
    fi
    
    # Ejecutar el comando
    if [[ "$log_output" == "true" ]]; then
        echo -e "${GREEN}Ejecutando: ${BLUE}$cmd${RESET}"
        eval "$cmd" 2>&1 | tee -a "$TOOLS_LOG"
        local status=${PIPESTATUS[0]}
    else
        echo -e "${GREEN}Ejecutando: ${BLUE}$cmd${RESET}"
        eval "$cmd" 2>&1
        local status=$?
    fi
    
    # Registrar resultado
    if [ $status -eq 0 ]; then
        log_action "RESULTADO" "Éxito (código: $status)"
        return 0
    else
        log_action "ERROR" "Fallo (código: $status)"
        return $status
    fi
}

# Función para crear o editar un archivo
edit_file() {
    local path="$1"
    local content="$2"
    local mode="$3" # "create", "append", "replace"
    
    # Crear directorio si no existe
    local dir_path=$(dirname "$path")
    if [ ! -d "$dir_path" ]; then
        execute_command "mkdir -p \"$dir_path\"" false
    fi
    
    # Manejar según el modo
    case "$mode" in
        "create")
            log_action "ARCHIVO" "Creando: $path"
            echo "$content" > "$path"
            ;;
        "append")
            log_action "ARCHIVO" "Añadiendo a: $path"
            echo "$content" >> "$path"
            ;;
        "replace")
            log_action "ARCHIVO" "Reemplazando: $path"
            echo "$content" > "$path"
            ;;
        *)
            log_action "ERROR" "Modo desconocido: $mode"
            return 1
            ;;
    esac
    
    # Verificar resultado
    if [ -f "$path" ]; then
        echo -e "${GREEN}Archivo $mode: ${BLUE}$path${RESET}"
        return 0
    else
        echo -e "${RED}Error al $mode archivo: ${YELLOW}$path${RESET}"
        return 1
    fi
}

# Función para abrir un IDE con un archivo específico
open_ide() {
    local ide="$1"      # "nano", "vscode-web", "arduino-web"
    local file_path="$2" # Ruta al archivo a abrir
    
    log_action "IDE" "Abriendo $ide con archivo: $file_path"
    
    # Verificar si el IDE está disponible
    case "$ide" in
        "nano")
            # En un entorno real, abriríamos nano con el archivo
            echo -e "${GREEN}Abriendo nano con el archivo: ${BLUE}$file_path${RESET}"
            echo -e "${YELLOW}(Simulado en Replit)${RESET}"
            # execute_command "nano \"$file_path\"" false
            ;;
        "vscode-web")
            # En un entorno real, abriríamos VS Code con el archivo
            echo -e "${GREEN}Abriendo VS Code con el archivo: ${BLUE}$file_path${RESET}"
            echo -e "${YELLOW}(Simulado en Replit)${RESET}"
            # execute_command "vscode-web \"$file_path\"" false
            ;;
        "arduino-web")
            # En un entorno real, abriríamos Arduino IDE con el archivo
            echo -e "${GREEN}Abriendo Arduino IDE con el archivo: ${BLUE}$file_path${RESET}"
            echo -e "${YELLOW}(Simulado en Replit)${RESET}"
            # execute_command "arduino-web \"$file_path\"" false
            ;;
        *)
            log_action "ERROR" "IDE desconocido: $ide"
            echo -e "${RED}IDE desconocido: ${YELLOW}$ide${RESET}"
            return 1
            ;;
    esac
    
    return 0
}

# Función para instalar paquetes
install_package() {
    local pkg_type="$1" # "system", "python", "nodejs", etc.
    local packages=("${@:2}") # Resto de argumentos son los paquetes
    
    log_action "INSTALAR" "$pkg_type: ${packages[*]}"
    
    case "$pkg_type" in
        "system")
            # En un entorno real, instalaríamos paquetes del sistema
            echo -e "${GREEN}Instalando paquetes del sistema: ${BLUE}${packages[*]}${RESET}"
            echo -e "${YELLOW}(Simulado en Replit)${RESET}"
            # execute_command "apt-get update && apt-get install -y ${packages[*]}" true
            ;;
        "python")
            # En un entorno real, instalaríamos paquetes de Python
            echo -e "${GREEN}Instalando paquetes de Python: ${BLUE}${packages[*]}${RESET}"
            execute_command "pip install ${packages[*]}" true
            ;;
        "nodejs")
            # En un entorno real, instalaríamos paquetes de Node.js
            echo -e "${GREEN}Instalando paquetes de Node.js: ${BLUE}${packages[*]}${RESET}"
            echo -e "${YELLOW}(Simulado en Replit)${RESET}"
            # execute_command "npm install ${packages[*]}" true
            ;;
        *)
            log_action "ERROR" "Tipo de paquete desconocido: $pkg_type"
            echo -e "${RED}Tipo de paquete desconocido: ${YELLOW}$pkg_type${RESET}"
            return 1
            ;;
    esac
    
    return 0
}

# Función para ejecutar un script de Python
run_python() {
    local script_path="$1"
    shift # Eliminar el primer argumento (script_path)
    local args=("$@") # Resto de argumentos
    
    log_action "PYTHON" "Ejecutando: $script_path ${args[*]}"
    
    # Verificar si el script existe
    if [ ! -f "$script_path" ]; then
        echo -e "${RED}El script de Python no existe: ${YELLOW}$script_path${RESET}"
        log_action "ERROR" "Script no encontrado: $script_path"
        return 1
    fi
    
    # Ejecutar el script
    echo -e "${GREEN}Ejecutando script Python: ${BLUE}$script_path ${args[*]}${RESET}"
    execute_command "python3 \"$script_path\" ${args[*]}" true
    return $?
}

# Función para ejecutar interacciones CLI con herramientas en Distro-Ruth
run_cli_tool() {
    local tool="$1"      # "ai-assistant", "ollama-agent", etc.
    local args=("${@:2}") # Resto de argumentos
    
    log_action "CLI" "Ejecutando herramienta: $tool ${args[*]}"
    
    # Verificar si la herramienta está disponible
    if [ "$tool" == "ai-assistant" ] || [ "$tool" == "ollama-agent" ] || [ "$tool" == "phi3-agent" ]; then
        echo -e "${GREEN}Ejecutando herramienta CLI: ${BLUE}$tool ${args[*]}${RESET}"
        echo -e "${YELLOW}(Simulado en Replit)${RESET}"
        # En un entorno real, ejecutaríamos la herramienta con los argumentos
        # execute_command "$tool ${args[*]}" true
    else
        log_action "ERROR" "Herramienta CLI desconocida: $tool"
        echo -e "${RED}Herramienta CLI desconocida: ${YELLOW}$tool${RESET}"
        return 1
    fi
    
    return 0
}

# Función para inicializar un proyecto con plantilla
init_project() {
    local project_type="$1" # "python", "nodejs", "html", etc.
    local project_name="$2" # Nombre del proyecto
    
    log_action "PROYECTO" "Inicializando proyecto $project_type: $project_name"
    
    # Crear directorio del proyecto
    execute_command "mkdir -p \"$project_name\"" false
    
    # Crear archivos según el tipo de proyecto
    case "$project_type" in
        "python")
            # Crear estructura básica de proyecto Python
            edit_file "$project_name/main.py" "#!/usr/bin/env python3\n\ndef main():\n    print(\"Hello, World!\")\n\nif __name__ == \"__main__\":\n    main()" "create"
            edit_file "$project_name/requirements.txt" "" "create"
            edit_file "$project_name/README.md" "# $project_name\n\nA Python project created by Distro-Ruth Phi-3 Agent.\n" "create"
            ;;
        "nodejs")
            # Crear estructura básica de proyecto Node.js
            edit_file "$project_name/index.js" "console.log('Hello, World!');" "create"
            edit_file "$project_name/package.json" "{\n  \"name\": \"$project_name\",\n  \"version\": \"1.0.0\",\n  \"description\": \"Project created by Distro-Ruth Phi-3 Agent\",\n  \"main\": \"index.js\",\n  \"scripts\": {\n    \"start\": \"node index.js\"\n  }\n}" "create"
            edit_file "$project_name/README.md" "# $project_name\n\nA Node.js project created by Distro-Ruth Phi-3 Agent.\n" "create"
            ;;
        "html")
            # Crear estructura básica de proyecto HTML
            edit_file "$project_name/index.html" "<!DOCTYPE html>\n<html>\n<head>\n    <title>$project_name</title>\n    <link rel=\"stylesheet\" href=\"style.css\">\n</head>\n<body>\n    <h1>$project_name</h1>\n    <p>Created by Distro-Ruth Phi-3 Agent</p>\n    <script src=\"script.js\"></script>\n</body>\n</html>" "create"
            edit_file "$project_name/style.css" "body {\n    font-family: Arial, sans-serif;\n    margin: 0;\n    padding: 20px;\n    background-color: #f5f5f5;\n}\n\nh1 {\n    color: #333;\n}" "create"
            edit_file "$project_name/script.js" "console.log('Hello, World!');" "create"
            edit_file "$project_name/README.md" "# $project_name\n\nA HTML project created by Distro-Ruth Phi-3 Agent.\n" "create"
            ;;
        *)
            log_action "ERROR" "Tipo de proyecto desconocido: $project_type"
            echo -e "${RED}Tipo de proyecto desconocido: ${YELLOW}$project_type${RESET}"
            return 1
            ;;
    esac
    
    echo -e "${GREEN}Proyecto $project_type inicializado: ${BLUE}$project_name${RESET}"
    return 0
}

# Función principal
main() {
    local action="$1"
    shift # Eliminar el primer argumento (action)
    
    case "$action" in
        "execute")
            execute_command "$*" true
            ;;
        "edit")
            local path="$1"
            local mode="$2"
            # Leer contenido del archivo hasta encontrar una línea con solo "EOF"
            local content=""
            local line=""
            while IFS= read -r line; do
                if [ "$line" == "EOF" ]; then
                    break
                fi
                content="${content}${line}
"
            done
            edit_file "$path" "$content" "$mode"
            ;;
        "ide")
            open_ide "$@"
            ;;
        "install")
            install_package "$@"
            ;;
        "python")
            run_python "$@"
            ;;
        "cli")
            run_cli_tool "$@"
            ;;
        "init")
            init_project "$@"
            ;;
        "help")
            echo -e "${GREEN}Herramientas disponibles para el agente Phi-3:${RESET}"
            echo -e "${BLUE}execute [comando]${RESET} - Ejecutar un comando del sistema"
            echo -e "${BLUE}edit [ruta] [create|append|replace]${RESET} - Crear o editar un archivo"
            echo -e "${BLUE}ide [nano|vscode-web|arduino-web] [ruta]${RESET} - Abrir un IDE con un archivo"
            echo -e "${BLUE}install [system|python|nodejs] [paquetes...]${RESET} - Instalar paquetes"
            echo -e "${BLUE}python [script] [args...]${RESET} - Ejecutar un script de Python"
            echo -e "${BLUE}cli [herramienta] [args...]${RESET} - Ejecutar una herramienta de Distro-Ruth"
            echo -e "${BLUE}init [python|nodejs|html] [nombre]${RESET} - Inicializar un proyecto"
            echo -e "${BLUE}help${RESET} - Mostrar esta ayuda"
            ;;
        *)
            echo -e "${RED}Acción desconocida: ${YELLOW}$action${RESET}"
            echo -e "${BLUE}Usa 'help' para ver las acciones disponibles.${RESET}"
            return 1
            ;;
    esac
    
    return $?
}

# Ejecutar la función principal con todos los argumentos
main "$@"