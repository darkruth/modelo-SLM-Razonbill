#!/usr/bin/env python3
# AI Programming Assistant for Minimal Debian Proot Environment

import os
import sys
import curses
import requests
import json
import textwrap
from config import get_api_key

def init_colors():
    """Initialize color pairs for the UI."""
    curses.start_color()
    curses.init_pair(1, curses.COLOR_GREEN, curses.COLOR_BLACK)  # User messages
    curses.init_pair(2, curses.COLOR_CYAN, curses.COLOR_BLACK)   # AI messages
    curses.init_pair(3, curses.COLOR_WHITE, curses.COLOR_BLUE)   # Headers
    curses.init_pair(4, curses.COLOR_BLACK, curses.COLOR_WHITE)  # Input area
    curses.init_pair(5, curses.COLOR_YELLOW, curses.COLOR_BLACK) # System messages

class ChatWindow:
    def __init__(self, stdscr):
        self.stdscr = stdscr
        self.chat_history = []
        self.input_buffer = ""
        self.cursor_pos = 0
        self.scroll_pos = 0
        self.max_height, self.max_width = stdscr.getmaxyx()
        self.input_height = 3
        self.chat_height = self.max_height - self.input_height - 2
        self.api_key = get_api_key()
        
        if not self.api_key:
            self.chat_history.append({
                "role": "system", 
                "content": "WARNING: API key not set. Please configure your API key in /opt/ai-assistant/config.py."
            })
        
        # Add initial system message
        self.chat_history.append({
            "role": "system", 
            "content": "Welcome to the AI Programming Assistant. How can I help you with your programming task in this Debian environment?"
        })
    
    def resize(self):
        """Handle terminal resize."""
        self.max_height, self.max_width = self.stdscr.getmaxyx()
        self.chat_height = self.max_height - self.input_height - 2
    
    def draw_header(self):
        """Draw the header bar."""
        header = " AI Programming Assistant "
        x = (self.max_width - len(header)) // 2
        self.stdscr.attron(curses.color_pair(3))
        self.stdscr.addstr(0, 0, " " * self.max_width)
        self.stdscr.addstr(0, x, header)
        self.stdscr.attroff(curses.color_pair(3))
    
    def draw_footer(self):
        """Draw the footer with instructions."""
        footer = " Ctrl+C: Exit | Enter: Send | Up/Down: Scroll "
        self.stdscr.attron(curses.color_pair(3))
        self.stdscr.addstr(self.max_height-1, 0, " " * self.max_width)
        self.stdscr.addstr(self.max_height-1, 2, footer)
        self.stdscr.attroff(curses.color_pair(3))
    
    def draw_input_area(self):
        """Draw the input area where the user types."""
        start_y = self.max_height - self.input_height - 1
        
        # Draw input box
        self.stdscr.attron(curses.color_pair(4))
        for i in range(self.input_height):
            self.stdscr.addstr(start_y + i, 0, " " * self.max_width)
        self.stdscr.attroff(curses.color_pair(4))
        
        # Show the input text with cursor
        visible_text = self.input_buffer
        if len(visible_text) > self.max_width - 4:
            # Calculate display window around cursor
            cursor_view_start = max(0, self.cursor_pos - (self.max_width - 10))
            visible_text = visible_text[cursor_view_start:cursor_view_start + self.max_width - 4]
            cursor_display_pos = self.cursor_pos - cursor_view_start
        else:
            cursor_display_pos = self.cursor_pos
        
        # Draw prompt and text
        self.stdscr.attron(curses.color_pair(4))
        self.stdscr.addstr(start_y, 2, "> " + visible_text)
        
        # Position cursor
        try:
            self.stdscr.move(start_y, 4 + cursor_display_pos)
        except curses.error:
            # Handling potential curses error when cursor position is invalid
            pass
        
        self.stdscr.attroff(curses.color_pair(4))
    
    def draw_chat_history(self):
        """Draw the chat history."""
        # Calculate total height of all messages
        total_height = 0
        formatted_messages = []
        
        for msg in self.chat_history:
            role = msg["role"]
            content = msg["content"]
            
            if role == "user":
                prefix = "You: "
                color_pair = 1
            elif role == "assistant":
                prefix = "AI: "
                color_pair = 2
            else:  # system
                prefix = "System: "
                color_pair = 5
            
            # Wrap text to fit window width
            wrapped_content = textwrap.wrap(
                content, 
                width=self.max_width - 5,
                initial_indent=prefix,
                subsequent_indent=" " * len(prefix)
            )
            
            formatted_msg = {
                "lines": wrapped_content,
                "color": color_pair,
                "height": len(wrapped_content) + 1  # +1 for spacing
            }
            
            formatted_messages.append(formatted_msg)
            total_height += formatted_msg["height"]
        
        # Calculate what to display based on scroll position
        display_start = 0
        if total_height > self.chat_height:
            # Ensure scroll_pos is within valid range
            max_scroll = total_height - self.chat_height
            self.scroll_pos = max(0, min(self.scroll_pos, max_scroll))
            
            # Skip messages that are scrolled off the top
            height_so_far = 0
            for i, msg in enumerate(formatted_messages):
                height_so_far += msg["height"]
                if height_so_far > self.scroll_pos:
                    # Found the first message to display
                    display_start = i
                    # Adjust for partial message
                    lines_to_skip = max(0, msg["height"] - (height_so_far - self.scroll_pos))
                    formatted_messages[i]["lines"] = formatted_messages[i]["lines"][lines_to_skip:]
                    formatted_messages[i]["height"] -= lines_to_skip
                    break
        
        # Draw visible messages
        y = 1  # Start after header
        for msg in formatted_messages[display_start:]:
            if y >= self.chat_height + 1:  # +1 for header
                break
                
            self.stdscr.attron(curses.color_pair(msg["color"]))
            for line in msg["lines"]:
                if y < self.chat_height + 1:  # Check if we're still in the chat area
                    try:
                        self.stdscr.addstr(y, 2, line)
                    except curses.error:
                        # Handle potential curses error when writing near screen edges
                        pass
                    y += 1
                else:
                    break
            
            # Add spacing between messages
            if y < self.chat_height + 1:
                y += 1
            
            self.stdscr.attroff(curses.color_pair(msg["color"]))
    
    def send_message(self):
        """Send the current input buffer as a message to the AI API."""
        if not self.input_buffer.strip():
            return
        
        # Add user message to chat history
        self.chat_history.append({"role": "user", "content": self.input_buffer})
        self.input_buffer = ""
        self.cursor_pos = 0
        
        # Redraw to show user message
        self.update_display()
        
        if not self.api_key:
            self.chat_history.append({
                "role": "system", 
                "content": "Error: API key not configured. Please set your API key in /opt/ai-assistant/config.py."
            })
            return
        
        # Attempt to call API
        try:
            # Prepare context - only include user and assistant messages
            messages = []
            for msg in self.chat_history:
                if msg["role"] != "system" or len(messages) == 0:
                    messages.append({
                        "role": msg["role"],
                        "content": msg["content"]
                    })
            
            # System instruction prepend
            messages.insert(0, {
                "role": "system",
                "content": "You are an AI programming assistant in a minimal Debian Proot environment. Help the user with coding, debugging, and explaining programming concepts. The environment has VSCode Web, nano editor, and Arduino IDE pre-installed."
            })
            
            # Show "thinking" message
            self.chat_history.append({"role": "system", "content": "Thinking..."})
            self.update_display()
            
            # Remove the "thinking" message
            self.chat_history.pop()
            
            # Make API request (OpenAI-compatible API assumed)
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}"
            }
            
            payload = {
                "model": "gpt-3.5-turbo",  # Or other compatible model
                "messages": messages,
                "max_tokens": 1000
            }
            
            response = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers=headers,
                data=json.dumps(payload),
                timeout=30
            )
            
            if response.status_code == 200:
                data = response.json()
                ai_message = data["choices"][0]["message"]["content"]
                self.chat_history.append({"role": "assistant", "content": ai_message})
            else:
                error_msg = f"API Error: {response.status_code} - {response.text}"
                self.chat_history.append({"role": "system", "content": error_msg})
                
        except Exception as e:
            error_msg = f"Error: {str(e)}"
            self.chat_history.append({"role": "system", "content": error_msg})
    
    def handle_key(self, key):
        """Process a single keystroke."""
        if key == curses.KEY_RESIZE:
            self.resize()
            
        elif key == ord('\n'):  # Enter key
            self.send_message()
            
        elif key == curses.KEY_BACKSPACE or key == 127:  # Backspace
            if self.cursor_pos > 0:
                self.input_buffer = self.input_buffer[:self.cursor_pos-1] + self.input_buffer[self.cursor_pos:]
                self.cursor_pos -= 1
                
        elif key == curses.KEY_DC:  # Delete key
            if self.cursor_pos < len(self.input_buffer):
                self.input_buffer = self.input_buffer[:self.cursor_pos] + self.input_buffer[self.cursor_pos+1:]
                
        elif key == curses.KEY_LEFT:  # Left arrow
            if self.cursor_pos > 0:
                self.cursor_pos -= 1
                
        elif key == curses.KEY_RIGHT:  # Right arrow
            if self.cursor_pos < len(self.input_buffer):
                self.cursor_pos += 1
                
        elif key == curses.KEY_HOME:  # Home key
            self.cursor_pos = 0
            
        elif key == curses.KEY_END:  # End key
            self.cursor_pos = len(self.input_buffer)
            
        elif key == curses.KEY_UP:  # Up arrow for scrolling
            self.scroll_pos += 1
            
        elif key == curses.KEY_DOWN:  # Down arrow for scrolling
            self.scroll_pos = max(0, self.scroll_pos - 1)
            
        elif 32 <= key <= 126:  # Printable characters
            self.input_buffer = (
                self.input_buffer[:self.cursor_pos] + 
                chr(key) + 
                self.input_buffer[self.cursor_pos:]
            )
            self.cursor_pos += 1
    
    def update_display(self):
        """Update the entire display."""
        self.stdscr.clear()
        self.draw_header()
        self.draw_chat_history()
        self.draw_input_area()
        self.draw_footer()
        self.stdscr.refresh()
    
    def run(self):
        """Main loop for the chat interface."""
        curses.curs_set(1)  # Show cursor
        
        while True:
            try:
                self.update_display()
                key = self.stdscr.getch()
                
                if key == 3:  # Ctrl+C
                    break
                    
                self.handle_key(key)
                
            except KeyboardInterrupt:
                break
            except Exception as e:
                # Display error in chat
                self.chat_history.append({"role": "system", "content": f"Error: {str(e)}"})
                self.update_display()

def main(stdscr):
    """Main function to initialize and run the chat window."""
    # Initialize curses
    curses.curs_set(0)  # Hide cursor initially
    stdscr.clear()
    stdscr.refresh()
    
    # Initialize colors
    init_colors()
    
    # Create and run chat window
    chat = ChatWindow(stdscr)
    chat.run()

if __name__ == "__main__":
    # Start the curses application
    curses.wrapper(main)
