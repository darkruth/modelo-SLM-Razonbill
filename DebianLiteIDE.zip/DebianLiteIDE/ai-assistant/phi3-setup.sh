#!/bin/bash
# Script para configurar llama.cpp con el modelo Phi-3 Mini
# para Distro-Ruth

# Colores para la consola
PURPLE='\033[38;5;141m'
PINK='\033[38;5;212m'
BLUE='\033[38;5;117m'
GREEN='\033[38;5;84m'
YELLOW='\033[38;5;228m'
RED='\033[38;5;203m'
RESET='\033[0m'

# Directorio base
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODELS_DIR="$BASE_DIR/models"
PHI3_DIR="$MODELS_DIR/phi3"
LLAMACPP_DIR="$BASE_DIR/llama.cpp"

echo -e "${PURPLE}═════════════════════════════════════════════════${RESET}"
echo -e "${PINK}Configurando Phi-3 Mini para Distro-Ruth${RESET}"
echo -e "${PURPLE}═════════════════════════════════════════════════${RESET}"

# Función para verificar entorno
check_environment() {
    echo -e "${BLUE}Verificando entorno...${RESET}"
    
    # Verificar si estamos en un contenedor (como Replit)
    if [ -f "/.dockerenv" ] || grep -q 'container=lxc' /proc/1/environ 2>/dev/null; then
        echo -e "${YELLOW}Detectado entorno containerizado.${RESET}"
        echo -e "${YELLOW}Nota: En algunos contenedores como Replit, podría haber limitaciones.${RESET}"
    fi
    
    # Verificar dependencias
    echo -e "${BLUE}Verificando dependencias...${RESET}"
    
    # Lista de dependencias necesarias
    DEPS=("git" "build-essential" "cmake" "wget" "python3")
    MISSING_DEPS=()
    
    for dep in "${DEPS[@]}"; do
        if ! command -v $dep &> /dev/null; then
            MISSING_DEPS+=("$dep")
        fi
    done
    
    if [ ${#MISSING_DEPS[@]} -gt 0 ]; then
        echo -e "${YELLOW}Dependencias faltantes: ${MISSING_DEPS[*]}${RESET}"
        echo -e "${BLUE}Intentando instalar dependencias...${RESET}"
        
        # Intentar con apt (Debian/Ubuntu)
        if command -v apt &> /dev/null; then
            echo -e "${GREEN}Usando apt para instalar dependencias...${RESET}"
            apt update && apt install -y "${MISSING_DEPS[@]}" || {
                echo -e "${RED}Error al instalar dependencias con apt.${RESET}"
                echo -e "${YELLOW}Por favor, instala manualmente: ${MISSING_DEPS[*]}${RESET}"
                return 1
            }
        # Intentar con yum (CentOS/RHEL)
        elif command -v yum &> /dev/null; then
            echo -e "${GREEN}Usando yum para instalar dependencias...${RESET}"
            yum install -y "${MISSING_DEPS[@]}" || {
                echo -e "${RED}Error al instalar dependencias con yum.${RESET}"
                echo -e "${YELLOW}Por favor, instala manualmente: ${MISSING_DEPS[*]}${RESET}"
                return 1
            }
        # Intentar con pacman (Arch)
        elif command -v pacman &> /dev/null; then
            echo -e "${GREEN}Usando pacman para instalar dependencias...${RESET}"
            pacman -S --noconfirm "${MISSING_DEPS[@]}" || {
                echo -e "${RED}Error al instalar dependencias con pacman.${RESET}"
                echo -e "${YELLOW}Por favor, instala manualmente: ${MISSING_DEPS[*]}${RESET}"
                return 1
            }
        else
            echo -e "${RED}No se pudo detectar un gestor de paquetes compatible.${RESET}"
            echo -e "${YELLOW}Por favor, instala manualmente: ${MISSING_DEPS[*]}${RESET}"
            return 1
        fi
    fi
    
    echo -e "${GREEN}Todas las dependencias están instaladas.${RESET}"
    return 0
}

# Función para clonar/actualizar llama.cpp
setup_llamacpp() {
    echo -e "${BLUE}Configurando llama.cpp...${RESET}"
    
    # Crear directorio para modelos
    mkdir -p "$PHI3_DIR"
    
    # Verificar si llama.cpp ya está clonado
    if [ -d "$LLAMACPP_DIR" ]; then
        echo -e "${GREEN}Actualizando repositorio llama.cpp existente...${RESET}"
        cd "$LLAMACPP_DIR"
        git pull
    else
        echo -e "${GREEN}Clonando repositorio llama.cpp...${RESET}"
        git clone https://github.com/ggerganov/llama.cpp "$LLAMACPP_DIR"
        cd "$LLAMACPP_DIR"
    fi
    
    # Compilar llama.cpp
    echo -e "${BLUE}Compilando llama.cpp...${RESET}"
    make clean && make -j$(nproc)
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Compilación exitosa.${RESET}"
        return 0
    else
        echo -e "${RED}Error en la compilación.${RESET}"
        return 1
    fi
}

# Función para descargar el modelo Phi-3 Mini
download_phi3_model() {
    echo -e "${BLUE}Descargando modelo Phi-3 Mini...${RESET}"
    
    # Verificar si el modelo ya existe
    if [ -f "$PHI3_DIR/phi3.q4.gguf" ]; then
        echo -e "${YELLOW}El modelo ya existe. ¿Quieres descargarlo de nuevo? (s/n)${RESET}"
        read -r response
        if [[ "$response" != "s" && "$response" != "S" ]]; then
            echo -e "${GREEN}Usando modelo existente.${RESET}"
            return 0
        fi
    fi
    
    # Descargar el modelo
    echo -e "${GREEN}Descargando modelo Phi-3 Mini Q4...${RESET}"
    wget https://huggingface.co/bartowski/Phi-3-mini-4k-instruct-GGUF/resolve/main/Phi-3-mini-4k-instruct-Q4_K_M.gguf -O "$PHI3_DIR/phi3.q4.gguf"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Descarga completada con éxito.${RESET}"
        return 0
    else
        echo -e "${RED}Error al descargar el modelo.${RESET}"
        return 1
    fi
}

# Función para realizar la configuración completa
setup_all() {
    check_environment || return 1
    setup_llamacpp || return 1
    download_phi3_model || return 1
    
    echo -e "${PURPLE}═════════════════════════════════════════════════${RESET}"
    echo -e "${GREEN}Configuración completada con éxito.${RESET}"
    echo -e "${BLUE}Para ejecutar el modelo, usa:${RESET}"
    echo -e "${YELLOW}cd $LLAMACPP_DIR && ./main -m $PHI3_DIR/phi3.q4.gguf -n 512 --interactive --temp 0.2 --repeat_penalty 1.2${RESET}"
    echo -e "${PURPLE}═════════════════════════════════════════════════${RESET}"
    
    # Crear un enlace simbólico para facilitar el acceso
    ln -sf "$LLAMACPP_DIR/main" "$BASE_DIR/phi3-agent"
    chmod +x "$BASE_DIR/phi3-agent"
    
    return 0
}

# Ejecutar la configuración
setup_all