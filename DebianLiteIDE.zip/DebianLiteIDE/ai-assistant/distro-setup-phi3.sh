#!/bin/bash
# Script para configurar Phi-3 Mini en Distro-Ruth
# Este script descarga y compila todo lo necesario en la distro

# Colores para la consola
PURPLE='\033[38;5;141m'
PINK='\033[38;5;212m'
BLUE='\033[38;5;117m'
GREEN='\033[38;5;84m'
YELLOW='\033[38;5;228m'
RED='\033[38;5;203m'
RESET='\033[0m'

# Directorios
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
BUILD_DIR="$ROOT_DIR/build"
MODELS_DIR="$ROOT_DIR/models"
PHI3_DIR="$MODELS_DIR/phi3"

echo -e "${PURPLE}════════════════════════════════════════════════════════════${RESET}"
echo -e "${PINK}        Instalación de Phi-3 Mini en Distro-Ruth           ${RESET}"
echo -e "${PURPLE}════════════════════════════════════════════════════════════${RESET}"
echo -e "${BLUE}Este script descargará e instalará:${RESET}"
echo -e "${BLUE}- llama.cpp (motor de inferencia para modelos de lenguaje)${RESET}"
echo -e "${BLUE}- Phi-3 Mini (modelo de lenguaje de Microsoft)${RESET}"
echo

# Crear directorios necesarios
echo -e "${GREEN}Creando directorios necesarios...${RESET}"
mkdir -p "$BUILD_DIR" "$MODELS_DIR" "$PHI3_DIR"

# Instalar dependencias
echo -e "${GREEN}Instalando dependencias necesarias...${RESET}"
if [ -f "/.dockerenv" ] || grep -q 'container=lxc' /proc/1/environ 2>/dev/null; then
    echo -e "${YELLOW}Detectado entorno containerizado (Replit/Docker).${RESET}"
    echo -e "${YELLOW}Esto puede limitar algunas funcionalidades.${RESET}"
    
    # En Replit/contenedor, usar apt si está disponible
    if command -v apt &> /dev/null; then
        echo -e "${BLUE}Usando apt para instalar dependencias...${RESET}"
        apt update && apt install -y build-essential cmake git wget python3 python3-pip
    else
        echo -e "${RED}No se encontró apt. No se pueden instalar dependencias automáticamente.${RESET}"
        echo -e "${YELLOW}Por favor instala manualmente: build-essential cmake git wget python3${RESET}"
    fi
else
    # En sistemas normales, detectar gestor de paquetes
    if command -v apt &> /dev/null; then
        echo -e "${BLUE}Usando apt para instalar dependencias...${RESET}"
        sudo apt update && sudo apt install -y build-essential cmake git wget python3 python3-pip
    elif command -v yum &> /dev/null; then
        echo -e "${BLUE}Usando yum para instalar dependencias...${RESET}"
        sudo yum install -y gcc gcc-c++ make cmake git wget python3 python3-pip
    elif command -v pacman &> /dev/null; then
        echo -e "${BLUE}Usando pacman para instalar dependencias...${RESET}"
        sudo pacman -Sy --noconfirm base-devel cmake git wget python python-pip
    else
        echo -e "${RED}No se pudo detectar el gestor de paquetes.${RESET}"
        echo -e "${YELLOW}Por favor instala manualmente: compilador C++, cmake, git, wget, python3${RESET}"
    fi
fi

# Clonar llama.cpp
echo -e "${GREEN}Descargando llama.cpp...${RESET}"
cd "$BUILD_DIR"
if [ -d "llama.cpp" ]; then
    echo -e "${BLUE}Actualizando llama.cpp existente...${RESET}"
    cd llama.cpp
    git pull origin master
else
    echo -e "${BLUE}Clonando llama.cpp...${RESET}"
    git clone https://github.com/ggerganov/llama.cpp.git
    cd llama.cpp
fi

# Compilar llama.cpp
echo -e "${GREEN}Compilando llama.cpp...${RESET}"
make clean
make -j$(nproc) || make -j2

# Verificar si la compilación fue exitosa
if [ ! -f "main" ]; then
    echo -e "${RED}Error: La compilación de llama.cpp falló.${RESET}"
    exit 1
fi

# Crear enlace simbólico para el ejecutable
echo -e "${GREEN}Configurando ejecutable...${RESET}"
cp main "$ROOT_DIR/phi3-main"
chmod +x "$ROOT_DIR/phi3-main"

# Descargar modelo Phi-3
echo -e "${GREEN}Descargando modelo Phi-3 Mini...${RESET}"
cd "$PHI3_DIR"

# URL del modelo
MODEL_URL="https://huggingface.co/bartowski/Phi-3-mini-4k-instruct-GGUF/resolve/main/Phi-3-mini-4k-instruct-Q4_K_M.gguf"

# Verificar si el modelo ya existe
if [ -f "phi3.q4.gguf" ]; then
    echo -e "${YELLOW}El modelo ya existe.${RESET}"
    echo -e "${BLUE}¿Deseas descargarlo nuevamente? (s/n)${RESET}"
    read -r response
    if [[ "$response" == "s" || "$response" == "S" ]]; then
        echo -e "${BLUE}Descargando modelo nuevamente...${RESET}"
        wget -O phi3.q4.gguf "$MODEL_URL"
    fi
else
    echo -e "${BLUE}Descargando modelo por primera vez...${RESET}"
    wget -O phi3.q4.gguf "$MODEL_URL"
fi

# Verificar si la descarga fue exitosa
if [ ! -f "phi3.q4.gguf" ]; then
    echo -e "${RED}Error: La descarga del modelo Phi-3 falló.${RESET}"
    exit 1
fi

# Crear script de ejecución
echo -e "${GREEN}Creando script de ejecución...${RESET}"
cat > "$ROOT_DIR/run-phi3.sh" << 'EOL'
#!/bin/bash
# Script para ejecutar Phi-3 Mini en Distro-Ruth

# Colores
PURPLE='\033[38;5;141m'
PINK='\033[38;5;212m'
BLUE='\033[38;5;117m'
GREEN='\033[38;5;84m'
RESET='\033[0m'

# Directorios
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODEL_PATH="$SCRIPT_DIR/models/phi3/phi3.q4.gguf"
EXEC_PATH="$SCRIPT_DIR/phi3-main"

# Prompt del sistema
SYSTEM_PROMPT="Eres un asistente de programación experto en Distro-Ruth. Ayudas con código, comandos, scripts y solución de problemas técnicos. Tus respuestas son claras, precisas y útiles."

# Verificar si existen los archivos necesarios
if [ ! -f "$MODEL_PATH" ]; then
    echo -e "${PINK}Error: No se encontró el modelo Phi-3.${RESET}"
    echo -e "${BLUE}Ejecuta primero ./ai-assistant/distro-setup-phi3.sh${RESET}"
    exit 1
fi

if [ ! -f "$EXEC_PATH" ]; then
    echo -e "${PINK}Error: No se encontró el ejecutable de llama.cpp.${RESET}"
    echo -e "${BLUE}Ejecuta primero ./ai-assistant/distro-setup-phi3.sh${RESET}"
    exit 1
fi

# Banner
echo -e "${PURPLE}════════════════════════════════════════════════════════════${RESET}"
echo -e "${PINK}        Asistente de Programación Phi-3 de Distro-Ruth      ${RESET}"
echo -e "${PURPLE}════════════════════════════════════════════════════════════${RESET}"
echo -e "${BLUE}Modelo: Phi-3 Mini (4K context)${RESET}"
echo -e "${BLUE}Modo: Interactivo${RESET}"
echo -e "${BLUE}Presiona Ctrl+C para salir${RESET}"
echo

# Ejecutar el modelo
"$EXEC_PATH" \
    -m "$MODEL_PATH" \
    -n 1024 \
    --interactive \
    --temp 0.2 \
    --repeat_penalty 1.2 \
    -p "SYSTEM: $SYSTEM_PROMPT

USER: "
EOL

# Hacer ejecutable el script
chmod +x "$ROOT_DIR/run-phi3.sh"

# Finalizar
echo -e "${PURPLE}════════════════════════════════════════════════════════════${RESET}"
echo -e "${GREEN}¡Instalación completada con éxito!${RESET}"
echo -e "${BLUE}Para ejecutar el modelo Phi-3, usa:${RESET}"
echo -e "${YELLOW}./run-phi3.sh${RESET}"
echo -e "${PURPLE}════════════════════════════════════════════════════════════${RESET}"