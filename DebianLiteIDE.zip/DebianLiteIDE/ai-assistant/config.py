#!/usr/bin/env python3
# Configuration file for AI Assistant

import os
import sys

# Configuration file location
CONFIG_DIR = os.path.expanduser("~/.config/ai-assistant")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")

def get_api_key():
    """Retrieve API key with the following priority:
    1. Environment variable AI_API_KEY
    2. Config file in ~/.config/ai-assistant/config.json
    3. Ask user to input
    """
    # Check environment variable
    api_key = os.environ.get("AI_API_KEY")
    if api_key:
        return api_key
    
    # Check config file
    try:
        if os.path.exists(CONFIG_FILE):
            import json
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                api_key = config.get("api_key")
                if api_key:
                    return api_key
    except Exception:
        pass
    
    # If running in terminal mode, prompt for API key
    if sys.stdout.isatty():
        try:
            print("\nAPI key not found. You need to configure your API key.")
            print("You can:")
            print("  1. Set environment variable: export AI_API_KEY=your_key")
            print("  2. Enter your API key now to save in config file")
            print("  3. Edit the config file later at ~/.config/ai-assistant/config.json\n")
            
            response = input("Would you like to enter your API key now? (y/n): ")
            if response.lower() in ('y', 'yes'):
                api_key = input("Enter your API key: ").strip()
                if api_key:
                    # Save to config file
                    save_api_key(api_key)
                    return api_key
        except KeyboardInterrupt:
            print("\nCancelled API key input.")
    
    return None

def save_api_key(api_key):
    """Save the API key to the config file."""
    import json
    
    # Create config directory if it doesn't exist
    os.makedirs(CONFIG_DIR, exist_ok=True)
    
    # Write config file
    with open(CONFIG_FILE, 'w') as f:
        json.dump({"api_key": api_key}, f)
    
    # Set appropriate permissions (readable only by user)
    os.chmod(CONFIG_FILE, 0o600)
    
    print(f"API key saved to {CONFIG_FILE}")

if __name__ == "__main__":
    # If run directly, allow setting/updating API key
    if len(sys.argv) > 1 and sys.argv[1] == "--set-key":
        if len(sys.argv) > 2:
            api_key = sys.argv[2]
            save_api_key(api_key)
        else:
            try:
                api_key = input("Enter your API key: ").strip()
                if api_key:
                    save_api_key(api_key)
                else:
                    print("No API key provided, operation cancelled.")
            except KeyboardInterrupt:
                print("\nOperation cancelled.")
    else:
        # Print current API key status
        api_key = get_api_key()
        if api_key:
            print(f"API key is configured. First 4 characters: {api_key[:4]}...")
        else:
            print("API key is not configured.")
            print("Configure it with: config.py --set-key YOUR_API_KEY")
            print("Or set environment variable: export AI_API_KEY=your_key")
