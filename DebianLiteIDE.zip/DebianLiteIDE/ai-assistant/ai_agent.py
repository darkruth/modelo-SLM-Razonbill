#!/usr/bin/env python3
"""
AI Code Agent for Distro-Ruth
This module provides the functionality for the AI programming assistant.
It supports both OpenAI and Anthropic models for generating code and answers.
"""

import os
import sys
import json
import curses
import textwrap
import time
from datetime import datetime
import threading
import re
import argparse

# Check for required modules
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    print("OpenAI library not available. Install with: pip install openai")
    OPENAI_AVAILABLE = False

try:
    import anthropic
    from anthropic import Anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    print("Anthropic library not available. Install with: pip install anthropic")
    ANTHROPIC_AVAILABLE = False

# Constants
CONFIG_DIR = os.path.expanduser("~/.config/distro-ruth")
CONFIG_FILE = os.path.join(CONFIG_DIR, "ai-config.json")
CHAT_HISTORY_FILE = os.path.join(CONFIG_DIR, "chat-history.json")
API_KEY_ENV_VAR = "OPENAI_API_KEY"  # Default to OpenAI
ANTHROPIC_KEY_ENV_VAR = "ANTHROPIC_API_KEY"

# AI model defaults
DEFAULT_MODEL = "gpt-4o"  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024
ANTHROPIC_MODEL = "claude-3-5-sonnet-20241022"  # the newest Anthropic model is "claude-3-5-sonnet-20241022" which was released October 22, 2024

# UI Settings
MAX_WIDTH = 100  # Max width for text display
INPUT_HEIGHT = 3  # Height of input area
CODE_THEME = "dracula"  # Theme for code syntax highlighting


class AICodeAgent:
    """Main class for the AI Code Agent functionality"""
    
    def __init__(self, model_provider="openai"):
        """Initialize the AI Code Agent with the specified model provider"""
        self.model_provider = model_provider
        self.api_key = None
        self.chat_history = []
        self.clients = {
            "openai": None,
            "anthropic": None
        }
        
        # Ensure config directory exists
        if not os.path.exists(CONFIG_DIR):
            os.makedirs(CONFIG_DIR)
        
        # Load configuration
        self.load_config()
        
        # Initialize client for the chosen provider
        self._init_client()
    
    def load_config(self):
        """Load configuration from config file"""
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, 'r') as f:
                    config = json.load(f)
                    
                    # Load API keys if available
                    if "openai_api_key" in config:
                        self.api_key = config["openai_api_key"]
                        os.environ[API_KEY_ENV_VAR] = self.api_key
                    
                    if "anthropic_api_key" in config:
                        os.environ[ANTHROPIC_KEY_ENV_VAR] = config["anthropic_api_key"]
                    
                    # Load model provider if available
                    if "model_provider" in config:
                        self.model_provider = config["model_provider"]
                        
                    # Load chat history if available
                    if os.path.exists(CHAT_HISTORY_FILE):
                        with open(CHAT_HISTORY_FILE, 'r') as hf:
                            self.chat_history = json.load(hf)
            except (json.JSONDecodeError, IOError) as e:
                print(f"Error loading configuration: {e}")
    
    def save_config(self):
        """Save configuration to config file"""
        config = {
            "model_provider": self.model_provider
        }
        
        # Only save API keys if they exist
        if API_KEY_ENV_VAR in os.environ:
            config["openai_api_key"] = os.environ[API_KEY_ENV_VAR]
        
        if ANTHROPIC_KEY_ENV_VAR in os.environ:
            config["anthropic_api_key"] = os.environ[ANTHROPIC_KEY_ENV_VAR]
        
        try:
            with open(CONFIG_FILE, 'w') as f:
                json.dump(config, f)
        except IOError as e:
            print(f"Error saving configuration: {e}")
    
    def save_chat_history(self):
        """Save chat history to file"""
        try:
            with open(CHAT_HISTORY_FILE, 'w') as f:
                json.dump(self.chat_history, f)
        except IOError as e:
            print(f"Error saving chat history: {e}")
    
    def _init_client(self):
        """Initialize the appropriate AI client based on provider"""
        try:
            if self.model_provider == "openai":
                if not OPENAI_AVAILABLE:
                    print("Error: OpenAI library not installed. Run 'pip install openai' to install.")
                    return False
                
                api_key = os.environ.get(API_KEY_ENV_VAR)
                if not api_key:
                    print(f"Error: {API_KEY_ENV_VAR} environment variable not set.")
                    return False
                
                self.clients["openai"] = OpenAI(api_key=api_key)
                return True
            
            elif self.model_provider == "anthropic":
                if not ANTHROPIC_AVAILABLE:
                    print("Error: Anthropic library not installed. Run 'pip install anthropic' to install.")
                    return False
                
                api_key = os.environ.get(ANTHROPIC_KEY_ENV_VAR)
                if not api_key:
                    print(f"Error: {ANTHROPIC_KEY_ENV_VAR} environment variable not set.")
                    return False
                
                self.clients["anthropic"] = Anthropic(api_key=api_key)
                return True
            
            else:
                print(f"Error: Unknown model provider '{self.model_provider}'. Use 'openai' or 'anthropic'.")
                return False
        
        except Exception as e:
            print(f"Error initializing AI client: {str(e)}")
            return False
    
    def set_api_key(self, api_key, provider="openai"):
        """Set the API key for the specified provider"""
        if provider == "openai":
            os.environ[API_KEY_ENV_VAR] = api_key
            self.api_key = api_key
        elif provider == "anthropic":
            os.environ[ANTHROPIC_KEY_ENV_VAR] = api_key
        
        self.model_provider = provider
        self._init_client()
        self.save_config()
        return True
    
    def generate_response(self, user_message, system_prompt=None, streaming=True):
        """Generate a response from the AI model"""
        # First check dependencies and API keys
        if self.model_provider == "openai" and not OPENAI_AVAILABLE:
            return "Error: OpenAI Python library not installed.\nRun 'pip install openai' to install it."
        
        if self.model_provider == "anthropic" and not ANTHROPIC_AVAILABLE:
            return "Error: Anthropic Python library not installed.\nRun 'pip install anthropic' to install it."
        
        # Check API keys
        if self.model_provider == "openai" and not os.environ.get(API_KEY_ENV_VAR):
            return f"Error: OpenAI API key not set.\nSet it with: ai-assistant --set-key YOUR_API_KEY\nOr export {API_KEY_ENV_VAR}=YOUR_API_KEY"
        
        if self.model_provider == "anthropic" and not os.environ.get(ANTHROPIC_KEY_ENV_VAR):
            return f"Error: Anthropic API key not set.\nSet it with: ai-assistant --set-key YOUR_API_KEY --anthropic\nOr export {ANTHROPIC_KEY_ENV_VAR}=YOUR_API_KEY"
        
        # Initialize client
        if not self._init_client():
            return f"Error initializing AI client for {self.model_provider}.\nCheck API key and internet connection."
        
        # Add user message to history
        self.chat_history.append({
            "role": "user",
            "content": user_message,
            "timestamp": datetime.now().isoformat()
        })
        
        # Default system prompt for code agent
        if system_prompt is None:
            system_prompt = (
                "You are an expert coding assistant built into the Distro-Ruth CLI environment. "
                "Your primary purpose is to help with programming tasks, explain code, and provide "
                "technical solutions. When providing code, use syntax highlighting and follow best practices. "
                "Be concise but thorough, and include explanations with your code. "
                "For questions about the CLI, explain commands and interface features clearly."
            )
        
        # Process based on provider
        try:
            if self.model_provider == "openai":
                return self._openai_generate(user_message, system_prompt, streaming)
            elif self.model_provider == "anthropic":
                return self._anthropic_generate(user_message, system_prompt, streaming)
            else:
                error_msg = f"Unknown model provider '{self.model_provider}'. Use 'openai' or 'anthropic'."
                print(error_msg)
                return error_msg
        except Exception as e:
            error_message = f"Error generating response from {self.model_provider}: {str(e)}"
            print(error_message)
            
            # Add error message to history
            self.chat_history.append({
                "role": "assistant",
                "content": error_message,
                "timestamp": datetime.now().isoformat(),
                "error": True
            })
            self.save_chat_history()
            
            return error_message
    
    def _openai_generate(self, user_message, system_prompt, streaming=True):
        """Generate response using OpenAI API"""
        messages = [
            {"role": "system", "content": system_prompt}
        ]
        
        # Add chat history (limit to last 10 messages to save tokens)
        for msg in self.chat_history[-10:]:
            messages.append({
                "role": msg["role"],
                "content": msg["content"]
            })
        
        try:
            if streaming:
                response_chunks = []
                response = self.clients["openai"].chat.completions.create(
                    model=DEFAULT_MODEL,
                    messages=messages,
                    stream=True
                )
                
                for chunk in response:
                    if chunk.choices[0].delta.content:
                        response_chunks.append(chunk.choices[0].delta.content)
                        yield chunk.choices[0].delta.content
                
                # Save full response to history
                full_response = "".join(response_chunks)
                self.chat_history.append({
                    "role": "assistant",
                    "content": full_response,
                    "timestamp": datetime.now().isoformat()
                })
                self.save_chat_history()
            else:
                response = self.clients["openai"].chat.completions.create(
                    model=DEFAULT_MODEL,
                    messages=messages
                )
                
                response_text = response.choices[0].message.content
                
                # Save to history
                self.chat_history.append({
                    "role": "assistant",
                    "content": response_text,
                    "timestamp": datetime.now().isoformat()
                })
                self.save_chat_history()
                
                return response_text
        
        except Exception as e:
            return f"Error generating OpenAI response: {str(e)}"
    
    def _anthropic_generate(self, user_message, system_prompt, streaming=True):
        """Generate response using Anthropic API"""
        messages = []
        
        # Add chat history (limit to last 10 messages to save tokens)
        for msg in self.chat_history[-10:]:
            role = "user" if msg["role"] == "user" else "assistant"
            messages.append({
                "role": role,
                "content": msg["content"]
            })
        
        try:
            if streaming:
                response_chunks = []
                response = self.clients["anthropic"].messages.create(
                    model=ANTHROPIC_MODEL,
                    system=system_prompt,
                    messages=messages,
                    max_tokens=2000,
                    stream=True
                )
                
                for chunk in response:
                    if hasattr(chunk, 'delta') and hasattr(chunk.delta, 'text'):
                        response_chunks.append(chunk.delta.text)
                        yield chunk.delta.text
                
                # Save full response to history
                full_response = "".join(response_chunks)
                self.chat_history.append({
                    "role": "assistant",
                    "content": full_response,
                    "timestamp": datetime.now().isoformat()
                })
                self.save_chat_history()
            else:
                response = self.clients["anthropic"].messages.create(
                    model=ANTHROPIC_MODEL,
                    system=system_prompt,
                    messages=messages,
                    max_tokens=2000
                )
                
                response_text = response.content[0].text
                
                # Save to history
                self.chat_history.append({
                    "role": "assistant",
                    "content": response_text,
                    "timestamp": datetime.now().isoformat()
                })
                self.save_chat_history()
                
                return response_text
        
        except Exception as e:
            return f"Error generating Anthropic response: {str(e)}"


class TerminalUI:
    """Terminal User Interface for the AI Code Agent"""
    
    def __init__(self, stdscr, ai_agent):
        """Initialize the terminal UI with the specified AI agent"""
        self.stdscr = stdscr
        self.ai_agent = ai_agent
        
        # Initialize curses
        curses.curs_set(1)  # Show cursor
        curses.use_default_colors()
        curses.start_color()
        
        # Initialize color pairs
        self.init_colors()
        
        # Window dimensions
        self.height, self.width = stdscr.getmaxyx()
        
        # Input buffer
        self.input_buffer = ""
        self.cursor_pos = 0
        
        # Chat display buffer
        self.chat_display = []
        
        # Scroll position
        self.scroll_pos = 0
        
        # Load chat history
        self.load_chat_history()
    
    def init_colors(self):
        """Initialize color pairs for the UI"""
        # Base colors for DraculaX theme
        curses.init_pair(1, 141, -1)  # Purple for UI elements
        curses.init_pair(2, 212, -1)  # Pink for highlights
        curses.init_pair(3, 117, -1)  # Light blue for user input
        curses.init_pair(4, 84, -1)   # Green for system messages
        curses.init_pair(5, 228, -1)  # Yellow for warnings
        curses.init_pair(6, 203, -1)  # Red for errors
        curses.init_pair(7, 255, -1)  # White for normal text
        
        # Color definitions
        self.COLOR_HEADER = curses.color_pair(1)
        self.COLOR_HIGHLIGHT = curses.color_pair(2)
        self.COLOR_USER = curses.color_pair(3)
        self.COLOR_SYSTEM = curses.color_pair(4)
        self.COLOR_WARNING = curses.color_pair(5)
        self.COLOR_ERROR = curses.color_pair(6)
        self.COLOR_NORMAL = curses.color_pair(7)
    
    def load_chat_history(self):
        """Load chat history from the AI agent"""
        for msg in self.ai_agent.chat_history:
            self.chat_display.append({
                "role": msg["role"],
                "content": msg["content"].splitlines()
            })
    
    def resize(self):
        """Handle terminal resize event"""
        self.height, self.width = self.stdscr.getmaxyx()
        self.stdscr.clear()
        self.update_display()
    
    def draw_header(self):
        """Draw the header bar"""
        # Calculate centered title
        title = "Distro-Ruth AI Code Agent"
        x = max(0, (self.width - len(title)) // 2)
        
        # Draw top border
        self.stdscr.addstr(0, 0, "═" * self.width, self.COLOR_HEADER)
        
        # Draw title
        self.stdscr.addstr(1, x, title, self.COLOR_HIGHLIGHT | curses.A_BOLD)
        
        # Draw model info
        model_info = f"Model: {DEFAULT_MODEL if self.ai_agent.model_provider == 'openai' else ANTHROPIC_MODEL}"
        self.stdscr.addstr(1, 2, model_info, self.COLOR_SYSTEM)
        
        # Draw bottom border
        self.stdscr.addstr(2, 0, "═" * self.width, self.COLOR_HEADER)
    
    def draw_footer(self):
        """Draw the footer with instructions"""
        footer_y = self.height - 2
        
        # Draw top border
        self.stdscr.addstr(footer_y - 1, 0, "═" * self.width, self.COLOR_HEADER)
        
        # Draw instructions
        instructions = "Ctrl+C: Exit | Up/Down: Scroll | Enter: Send | Tab: Code Block"
        x = max(0, (self.width - len(instructions)) // 2)
        self.stdscr.addstr(footer_y, x, instructions, self.COLOR_SYSTEM)
    
    def draw_input_area(self):
        """Draw the input area where the user types"""
        input_start_y = self.height - 3 - INPUT_HEIGHT
        
        # Draw border
        self.stdscr.addstr(input_start_y, 0, "╔" + "═" * (self.width - 2) + "╗", self.COLOR_HEADER)
        for i in range(INPUT_HEIGHT):
            self.stdscr.addstr(input_start_y + 1 + i, 0, "║", self.COLOR_HEADER)
            self.stdscr.addstr(input_start_y + 1 + i, self.width - 1, "║", self.COLOR_HEADER)
        self.stdscr.addstr(input_start_y + 1 + INPUT_HEIGHT, 0, "╚" + "═" * (self.width - 2) + "╝", self.COLOR_HEADER)
        
        # Draw prompt
        prompt = "You: "
        self.stdscr.addstr(input_start_y + 1, 2, prompt, self.COLOR_USER | curses.A_BOLD)
        
        # Calculate visible part of input buffer
        prompt_len = len(prompt) + 2  # +2 for padding
        visible_width = self.width - prompt_len - 3
        
        # Ensure cursor is in visible area
        if self.cursor_pos < 0:
            self.cursor_pos = 0
        elif self.cursor_pos > len(self.input_buffer):
            self.cursor_pos = len(self.input_buffer)
        
        # Display buffer with word wrap
        y_offset = 0
        x_offset = prompt_len
        
        # Simple word wrap for input
        buffer_lines = textwrap.wrap(self.input_buffer, width=visible_width) if self.input_buffer else [""]
        for i, line in enumerate(buffer_lines[:INPUT_HEIGHT]):
            if i < INPUT_HEIGHT:
                self.stdscr.addstr(input_start_y + 1 + i, prompt_len if i == 0 else 2, line, self.COLOR_NORMAL)
        
        # Position cursor
        cursor_x = prompt_len + self.cursor_pos
        cursor_y = input_start_y + 1
        
        # Adjust for word wrap
        while cursor_x >= self.width - 2:
            cursor_x -= (self.width - 4)
            cursor_y += 1
        
        self.stdscr.move(cursor_y, cursor_x)
    
    def draw_chat_history(self):
        """Draw the chat history"""
        chat_start_y = 3  # Start after header
        chat_height = self.height - 3 - INPUT_HEIGHT - 4  # Space for chat
        
        # Clear the chat area
        for i in range(chat_height):
            self.stdscr.addstr(chat_start_y + i, 0, " " * self.width)
        
        # Calculate how many messages to display
        displayable_messages = []
        current_y = 0
        
        # Go through messages from newest to oldest until we fill the screen
        for msg in reversed(self.chat_display):
            role = msg["role"]
            content_lines = msg["content"]
            
            # Calculate height of this message
            msg_height = len(content_lines) + 1  # +1 for the role indicator
            
            # Add message to displayable list if it fits
            if current_y + msg_height <= chat_height:
                displayable_messages.insert(0, msg)
                current_y += msg_height + 1  # +1 for spacing
            else:
                # If we're scrolled, keep adding older messages
                if self.scroll_pos > 0:
                    self.scroll_pos -= 1
                else:
                    break
        
        # Display messages
        current_y = chat_start_y
        for msg in displayable_messages:
            role = msg["role"]
            content_lines = msg["content"]
            
            # Display role with appropriate color
            role_text = "You: " if role == "user" else "AI: "
            role_color = self.COLOR_USER if role == "user" else self.COLOR_HIGHLIGHT
            self.stdscr.addstr(current_y, 2, role_text, role_color | curses.A_BOLD)
            current_y += 1
            
            # Display message content with proper formatting
            for line in content_lines:
                # Handle code blocks with syntax highlighting
                if line.strip().startswith("```"):
                    self.stdscr.addstr(current_y, 4, line, self.COLOR_SYSTEM)
                elif line.strip().startswith("`") and line.strip().endswith("`"):
                    self.stdscr.addstr(current_y, 4, line, self.COLOR_HIGHLIGHT)
                else:
                    self.stdscr.addstr(current_y, 4, line[:self.width-6], self.COLOR_NORMAL)
                
                current_y += 1
            
            # Add spacing between messages
            current_y += 1
            
            # Stop if we've reached the bottom of the chat area
            if current_y >= chat_start_y + chat_height:
                break
    
    def update_display(self):
        """Update the entire display"""
        self.stdscr.clear()
        self.draw_header()
        self.draw_chat_history()
        self.draw_input_area()
        self.draw_footer()
        self.stdscr.refresh()
    
    def insert_text(self, text):
        """Insert text at cursor position"""
        before = self.input_buffer[:self.cursor_pos]
        after = self.input_buffer[self.cursor_pos:]
        self.input_buffer = before + text + after
        self.cursor_pos += len(text)
    
    def send_message(self):
        """Send the current input buffer as a message to the AI API"""
        if not self.input_buffer.strip():
            return
        
        # Get the user message
        user_message = self.input_buffer.strip()
        
        # Clear the input buffer
        self.input_buffer = ""
        self.cursor_pos = 0
        
        # Add user message to chat display
        self.chat_display.append({
            "role": "user",
            "content": user_message.splitlines()
        })
        
        # Update the display
        self.update_display()
        
        # Create a thread for the AI response to avoid blocking the UI
        def get_ai_response():
            # Add a placeholder for the AI response
            ai_msg_idx = len(self.chat_display)
            self.chat_display.append({
                "role": "assistant",
                "content": ["Thinking..."]
            })
            self.update_display()
            
            # Buffer for collecting the full response
            full_response = []
            current_line = ""
            
            # Get streaming response
            for chunk in self.ai_agent.generate_response(user_message, streaming=True):
                # Append to the current line
                current_line += chunk
                
                # Handle newlines in chunks
                if '\n' in current_line:
                    lines = current_line.split('\n')
                    for i in range(len(lines) - 1):
                        full_response.append(lines[i])
                    current_line = lines[-1]
                
                # Update display with current progress
                self.chat_display[ai_msg_idx] = {
                    "role": "assistant",
                    "content": full_response + [current_line]
                }
                self.update_display()
                time.sleep(0.01)  # Small delay to avoid screen flicker
            
            # Add final line if not empty
            if current_line:
                full_response.append(current_line)
            
            # Update with the complete response
            self.chat_display[ai_msg_idx] = {
                "role": "assistant",
                "content": full_response
            }
            self.update_display()
        
        # Start the response thread
        threading.Thread(target=get_ai_response).start()
    
    def handle_key(self, key):
        """Process a single keystroke"""
        if key == curses.KEY_RESIZE:
            self.resize()
        
        elif key in (curses.KEY_ENTER, 10, 13):  # Enter key
            self.send_message()
        
        elif key == curses.KEY_BACKSPACE or key == 127:  # Backspace
            if self.cursor_pos > 0:
                self.input_buffer = self.input_buffer[:self.cursor_pos-1] + self.input_buffer[self.cursor_pos:]
                self.cursor_pos -= 1
        
        elif key == curses.KEY_DC:  # Delete key
            if self.cursor_pos < len(self.input_buffer):
                self.input_buffer = self.input_buffer[:self.cursor_pos] + self.input_buffer[self.cursor_pos+1:]
        
        elif key == curses.KEY_LEFT:  # Left arrow
            if self.cursor_pos > 0:
                self.cursor_pos -= 1
        
        elif key == curses.KEY_RIGHT:  # Right arrow
            if self.cursor_pos < len(self.input_buffer):
                self.cursor_pos += 1
        
        elif key == curses.KEY_UP:  # Up arrow - scroll chat history
            self.scroll_pos += 1
        
        elif key == curses.KEY_DOWN:  # Down arrow - scroll chat history
            if self.scroll_pos > 0:
                self.scroll_pos -= 1
        
        elif key == 9:  # Tab key - insert code block marker
            self.insert_text("```\n\n```")
            self.cursor_pos -= 4  # Position cursor inside the code block
        
        elif key == 24:  # Ctrl+X - clear buffer
            self.input_buffer = ""
            self.cursor_pos = 0
        
        elif 32 <= key <= 126:  # Printable ASCII characters
            self.insert_text(chr(key))
        
        self.update_display()
    
    def run(self):
        """Main loop for the chat interface"""
        # Initial update
        self.update_display()
        
        # Main loop
        while True:
            try:
                key = self.stdscr.getch()
                
                # Exit on Ctrl+C
                if key == 3:
                    break
                
                self.handle_key(key)
            
            except KeyboardInterrupt:
                break
            except Exception as e:
                # Log error and continue
                with open(os.path.join(CONFIG_DIR, "error.log"), "a") as f:
                    f.write(f"{datetime.now().isoformat()}: {str(e)}\n")
                continue


def main_ui(stdscr):
    """Main function to initialize and run the terminal UI"""
    # Create AI agent
    ai_agent = AICodeAgent()
    
    # Create and run UI
    ui = TerminalUI(stdscr, ai_agent)
    ui.run()


def command_line_interface():
    """Handle command-line arguments for the AI assistant"""
    parser = argparse.ArgumentParser(description="Distro-Ruth AI Code Agent")
    parser.add_argument("--set-key", help="Set the OpenAI API key")
    parser.add_argument("--set-anthropic-key", help="Set the Anthropic API key")
    parser.add_argument("--use-provider", choices=["openai", "anthropic"], help="Set the AI provider to use")
    parser.add_argument("--query", help="Single query mode: ask a question and exit")
    
    args = parser.parse_args()
    
    # Create AI agent
    ai_agent = AICodeAgent()
    
    # Handle API key setting
    if args.set_key:
        if ai_agent.set_api_key(args.set_key, "openai"):
            print("OpenAI API key set successfully.")
        else:
            print("Failed to set OpenAI API key.")
        return
    
    if args.set_anthropic_key:
        if ai_agent.set_api_key(args.set_anthropic_key, "anthropic"):
            print("Anthropic API key set successfully.")
        else:
            print("Failed to set Anthropic API key.")
        return
    
    # Handle provider setting
    if args.use_provider:
        ai_agent.model_provider = args.use_provider
        ai_agent.save_config()
        print(f"Now using {args.use_provider} as the AI provider.")
        return
    
    # Handle single query mode
    if args.query:
        print(f"Query: {args.query}")
        print("\nThinking...\n")
        
        response = ai_agent.generate_response(args.query, streaming=False)
        print("Response:\n")
        print(response)
        return
    
    # Launch interactive UI
    try:
        curses.wrapper(main_ui)
    except Exception as e:
        print(f"Error in UI: {e}")
        with open(os.path.join(CONFIG_DIR, "error.log"), "a") as f:
            f.write(f"{datetime.now().isoformat()}: {str(e)}\n")


if __name__ == "__main__":
    command_line_interface()