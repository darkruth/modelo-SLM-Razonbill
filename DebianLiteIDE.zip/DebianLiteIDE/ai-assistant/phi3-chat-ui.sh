#!/bin/bash
# Interfaz de chat mejorada para Phi-3 en Distro-Ruth
# Proporciona una interfaz de usuario TUI con capacidades de agente

# Colores para la consola
PURPLE='\033[38;5;141m'
PINK='\033[38;5;212m'
BLUE='\033[38;5;117m'
GREEN='\033[38;5;84m'
YELLOW='\033[38;5;228m'
RED='\033[38;5;203m'
WHITE='\033[38;5;255m'
RESET='\033[0m'

# Configuraciones
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
CHAT_HISTORY_FILE="$ROOT_DIR/.phi3-chat-history.txt"
MODEL_PATH="$ROOT_DIR/models/phi3/phi3.q4.gguf"
EXEC_PATH="$ROOT_DIR/phi3-main"

# Dimensiones de la ventana
TERM_COLS=$(tput cols) || TERM_COLS=80
TERM_ROWS=$(tput lines) || TERM_ROWS=24
HISTORY_HEIGHT=$((TERM_ROWS - 8))
INPUT_HEIGHT=3

# Crear archivo de historial si no existe
touch "$CHAT_HISTORY_FILE"

# Función para mostrar el banner
show_banner() {
    clear
    echo -e "${PURPLE}════════════════════════════════════════════════════════════${RESET}"
    echo -e "${PINK}         Phi-3 Mini - Asistente de Programación IA         ${RESET}"
    echo -e "${PURPLE}════════════════════════════════════════════════════════════${RESET}"
    echo -e "${BLUE}Escribe tus preguntas o instrucciones en lenguaje natural.${RESET}"
    echo -e "${BLUE}El asistente puede ayudarte con tareas de programación y sistema.${RESET}"
    echo -e "${GREEN}Presiona Ctrl+C para salir${RESET}"
    echo -e "${PURPLE}────────────────────────────────────────────────────────────${RESET}"
}

# Función para dibujar la interfaz gráfica TUI
draw_ui() {
    clear
    show_banner
    
    # Mostrar historial de chat (últimas N líneas)
    show_chat_history
    
    # Dibujar área de entrada
    echo -e "${PURPLE}────────────────────────────────────────────────────────────${RESET}"
    echo -e "${GREEN}Tu mensaje:${RESET}"
}

# Función para mostrar el historial de chat
show_chat_history() {
    # Calcular cuántas líneas mostrar
    local history_lines=$(($(wc -l < "$CHAT_HISTORY_FILE")))
    local start_line=1
    
    if [ "$history_lines" -gt "$HISTORY_HEIGHT" ]; then
        start_line=$((history_lines - HISTORY_HEIGHT + 1))
    fi
    
    # Mostrar historial con colores
    if [ "$history_lines" -gt 0 ]; then
        tail -n "$HISTORY_HEIGHT" "$CHAT_HISTORY_FILE" | while IFS= read -r line; do
            if [[ "$line" == "Usuario:"* ]]; then
                echo -e "${BLUE}$line${RESET}"
            elif [[ "$line" == "Phi-3:"* ]]; then
                echo -e "${GREEN}$line${RESET}"
            elif [[ "$line" == "Sistema:"* ]]; then
                echo -e "${YELLOW}$line${RESET}"
            else
                echo -e "${WHITE}$line${RESET}"
            fi
        done
    fi
}

# Función para añadir mensaje al historial
add_to_history() {
    local role="$1"
    local message="$2"
    
    # Dar formato al mensaje para el historial
    echo "$role: $message" >> "$CHAT_HISTORY_FILE"
}

# Función para ejecutar comandos del sistema cuando el agente lo solicita
execute_agent_command() {
    local command="$1"
    
    # Marcar la ejecución en el historial
    add_to_history "Sistema" "Ejecutando: $command"
    
    # Usar el script de herramientas si existe
    if [ -f "$SCRIPT_DIR/phi3-tools.sh" ]; then
        # Ejecutar el comando a través de las herramientas
        output=$("$SCRIPT_DIR/phi3-tools.sh" "execute" "$command" 2>&1)
    else
        # Fallback: ejecutar directamente
        output=$(eval "$command" 2>&1)
    fi
    
    # Guardar la salida en el historial
    add_to_history "Sistema" "Resultado:"
    echo "$output" | while IFS= read -r line; do
        add_to_history "Sistema" "  $line"
    done
}

# Función para manipular archivos cuando el agente lo solicita
manage_file() {
    local path="$1"
    local content="$2"
    local action="create"  # Por defecto, crear
    
    # Comprobar si el archivo ya existe
    if [ -f "$path" ]; then
        action="replace"
    fi
    
    # Marcar la acción en el historial
    add_to_history "Sistema" "$action archivo: $path"
    
    # Usar el script de herramientas si existe
    if [ -f "$SCRIPT_DIR/phi3-tools.sh" ]; then
        # Crear un archivo temporal con el contenido
        local temp_file=$(mktemp)
        echo "$content" > "$temp_file"
        echo "EOF" >> "$temp_file"
        
        # Ejecutar la herramienta con el contenido
        output=$("$SCRIPT_DIR/phi3-tools.sh" "edit" "$path" "$action" < "$temp_file" 2>&1)
        
        # Limpiar
        rm "$temp_file"
    else
        # Fallback: crear/editar directamente
        mkdir -p "$(dirname "$path")"
        echo "$content" > "$path"
        output="Archivo $action: $path"
    fi
    
    # Guardar la salida en el historial
    add_to_history "Sistema" "$output"
}

# Función para abrir un IDE con un archivo
open_ide() {
    local ide="$1"
    local path="$2"
    
    # Marcar la acción en el historial
    add_to_history "Sistema" "Abriendo $ide con archivo: $path"
    
    # Usar el script de herramientas si existe
    if [ -f "$SCRIPT_DIR/phi3-tools.sh" ]; then
        output=$("$SCRIPT_DIR/phi3-tools.sh" "ide" "$ide" "$path" 2>&1)
    else
        # Fallback: mensaje simple
        output="Simulando apertura de $ide con archivo: $path"
    fi
    
    # Guardar la salida en el historial
    add_to_history "Sistema" "$output"
}

# Función para instalar paquetes
install_packages() {
    local pkg_type="$1"
    shift
    local packages=("$@")
    
    # Marcar la acción en el historial
    add_to_history "Sistema" "Instalando paquetes $pkg_type: ${packages[*]}"
    
    # Usar el script de herramientas si existe
    if [ -f "$SCRIPT_DIR/phi3-tools.sh" ]; then
        output=$("$SCRIPT_DIR/phi3-tools.sh" "install" "$pkg_type" "${packages[@]}" 2>&1)
    else
        # Fallback: mensaje simple
        output="Simulando instalación de paquetes $pkg_type: ${packages[*]}"
    fi
    
    # Guardar la salida en el historial
    add_to_history "Sistema" "$output"
}

# Función para enviar mensaje a Phi-3 y obtener respuesta
send_to_phi3() {
    local user_message="$1"
    local phi3_prompt="$USER_PROMPT"
    local system_prompt="Eres un asistente de programación experto integrado en Distro-Ruth CLI. Puedes ayudar con código, comandos y tareas del sistema. Cuando necesites ejecutar un comando, indica 'EJECUTAR: [comando]' en una línea separada. Para crear o editar archivos, indica 'ARCHIVO: [ruta]' seguido por el contenido del archivo en las siguientes líneas, terminando con 'FIN_ARCHIVO'."
    
    # Verificar si tenemos el modelo y ejecutable
    if [ ! -f "$MODEL_PATH" ] || [ ! -f "$EXEC_PATH" ]; then
        add_to_history "Sistema" "Error: Modelo Phi-3 o ejecutable no encontrado."
        add_to_history "Sistema" "Por favor, ejecuta primero el script de instalación."
        return 1
    fi
    
    # Añadir el mensaje del usuario al historial
    add_to_history "Usuario" "$user_message"
    
    # Mostrar interfaz actualizada
    draw_ui
    echo -e "${YELLOW}Phi-3 está pensando...${RESET}"
    
    # Crear instrucciones detalladas para el modelo
    local system_prompt="Eres un asistente de programación especializado integrado en Distro-Ruth CLI. Puedes ayudar con código, comandos y tareas del sistema. Tienes la capacidad de interactuar con el sistema a través de estos comandos especiales:

1. Para ejecutar un comando: Escribe 'EJECUTAR: [comando]' en una línea separada.
   Ejemplo: EJECUTAR: ls -la

2. Para crear o editar archivos: Escribe 'ARCHIVO: [ruta]', seguido por el contenido del archivo, y termina con 'FIN_ARCHIVO'.
   Ejemplo:
   ARCHIVO: /home/user/script.py
   #!/usr/bin/env python3
   print('Hello world')
   FIN_ARCHIVO

3. Para abrir un IDE: Escribe 'IDE: [tipo_ide] [ruta_archivo]'
   Tipos de IDE disponibles: nano, vscode-web, arduino-web
   Ejemplo: IDE: vscode-web /home/user/script.py

4. Para instalar paquetes: Escribe 'INSTALAR: [tipo_paquete] [lista_paquetes]'
   Tipos de paquetes: system, python, nodejs
   Ejemplo: INSTALAR: python requests numpy

5. Para iniciar un proyecto: Escribe 'PROYECTO: [tipo_proyecto] [nombre_proyecto]'
   Tipos de proyecto: python, nodejs, html
   Ejemplo: PROYECTO: python mi_proyecto

Eres un experto en programación y debes proporcionar soluciones completas y funcionales a los problemas del usuario. Cuando te pidan crear un programa o script, debes crear los archivos necesarios y mostrar cómo ejecutarlo."

    # Crear un archivo temporal para el prompt
    local temp_file=$(mktemp)
    echo "SYSTEM: $system_prompt" > "$temp_file"
    echo "" >> "$temp_file"
    echo "USER: $user_message" >> "$temp_file"
    echo "" >> "$temp_file"
    echo "ASSISTANT: " >> "$temp_file"
    
    # Ejecutar Phi-3 y capturar la respuesta
    local response
    response=$("$EXEC_PATH" -m "$MODEL_PATH" -f "$temp_file" -n 2048 -t 0.2 --repeat-penalty 1.2)
    
    # Limpiar el archivo temporal
    rm "$temp_file"
    
    # Extraer solo la respuesta del asistente
    response=$(echo "$response" | grep -oP 'ASSISTANT:\s*\K.*')
    
    # Procesar la respuesta para detectar comandos
    process_phi3_response "$response"
}

# Función para procesar la respuesta de Phi-3 y ejecutar comandos si los hay
process_phi3_response() {
    local response="$1"
    local current_section=""
    local file_path=""
    local file_content=""
    local ide_type=""
    local pkg_type=""
    local pkg_list=""
    
    # Guardar la respuesta original en el historial
    add_to_history "Phi-3" "$response"
    
    # Procesar la respuesta línea por línea
    echo "$response" | while IFS= read -r line; do
        # Detectar comandos para ejecutar
        if [[ "$line" =~ ^EJECUTAR:\ *(.*) ]]; then
            local command="${BASH_REMATCH[1]}"
            # Ejecutar el comando
            execute_agent_command "$command"
            current_section=""
            
        # Detectar inicio de definición de archivo
        elif [[ "$line" =~ ^ARCHIVO:\ *(.*) ]]; then
            file_path="${BASH_REMATCH[1]}"
            file_content=""
            current_section="file"
            
        # Detectar fin de definición de archivo
        elif [[ "$line" == "FIN_ARCHIVO" && "$current_section" == "file" ]]; then
            # Crear el archivo
            manage_file "$file_path" "$file_content"
            current_section=""
            
        # Detectar comando para abrir IDE
        elif [[ "$line" =~ ^IDE:\ *([a-zA-Z0-9_-]+)\ +(.*) ]]; then
            ide_type="${BASH_REMATCH[1]}"
            file_path="${BASH_REMATCH[2]}"
            open_ide "$ide_type" "$file_path"
            
        # Detectar comando para instalar paquetes
        elif [[ "$line" =~ ^INSTALAR:\ *([a-zA-Z0-9_-]+)\ +(.*) ]]; then
            pkg_type="${BASH_REMATCH[1]}"
            pkg_list="${BASH_REMATCH[2]}"
            # Convertir lista de paquetes en array
            IFS=' ' read -r -a packages <<< "$pkg_list"
            install_packages "$pkg_type" "${packages[@]}"
            
        # Detectar comando para inicializar proyecto
        elif [[ "$line" =~ ^PROYECTO:\ *([a-zA-Z0-9_-]+)\ +(.*) ]]; then
            local proj_type="${BASH_REMATCH[1]}"
            local proj_name="${BASH_REMATCH[2]}"
            
            if [ -f "$SCRIPT_DIR/phi3-tools.sh" ]; then
                output=$("$SCRIPT_DIR/phi3-tools.sh" "init" "$proj_type" "$proj_name" 2>&1)
                add_to_history "Sistema" "$output"
            else
                add_to_history "Sistema" "Simulando creación de proyecto $proj_type: $proj_name"
            fi
            
        # Acumular contenido de archivo
        elif [[ "$current_section" == "file" ]]; then
            file_content="${file_content}${line}
"
        fi
    done
    
    # Actualizar la interfaz
    draw_ui
}

# Función para la interfaz de chat interactiva
interactive_chat() {
    while true; do
        # Dibujar la interfaz
        draw_ui
        
        # Leer la entrada del usuario
        read -e -p "> " user_input
        
        # Verificar si el usuario quiere salir
        if [[ "$user_input" == "salir" || "$user_input" == "exit" ]]; then
            break
        fi
        
        # Procesar la entrada del usuario
        if [[ -n "$user_input" ]]; then
            send_to_phi3 "$user_input"
        fi
    done
}

# Función principal
main() {
    # Verificar si estamos en un entorno containerizado
    if [ -f "/.dockerenv" ] || grep -q 'container=lxc' /proc/1/environ 2>/dev/null; then
        show_banner
        echo -e "${RED}Estás ejecutando Distro-Ruth en un entorno containerizado.${RESET}"
        echo -e "${RED}En este entorno, el chat con Phi-3 está en modo simulado.${RESET}"
        echo -e "${YELLOW}En un entorno local real, tendrías acceso completo a la IA.${RESET}"
        echo
        echo -e "${BLUE}Presiona Enter para iniciar el chat simulado o Ctrl+C para salir.${RESET}"
        read
        
        # Modo simulado
        while true; do
            draw_ui
            read -e -p "> " user_input
            
            if [[ "$user_input" == "salir" || "$user_input" == "exit" ]]; then
                break
            fi
            
            if [[ -n "$user_input" ]]; then
                add_to_history "Usuario" "$user_input"
                draw_ui
                echo -e "${YELLOW}Phi-3 está pensando...${RESET}"
                sleep 1
                
                # Respuesta simulada con integración de comandos básicos
                if [[ "$user_input" == *"crea"* && "$user_input" == *"python"* ]] || 
                   [[ "$user_input" == *"escribe"* && "$user_input" == *"script"* ]] ||
                   [[ "$user_input" == *"haz"* && "$user_input" == *"programa"* ]]; then
                    
                    # Simular creación de script Python
                    add_to_history "Phi-3" "Claro, puedo crear un script de Python para ti. Aquí tienes un ejemplo:"
                    add_to_history "Phi-3" "ARCHIVO: ejemplo.py"
                    add_to_history "Phi-3" "#!/usr/bin/env python3"
                    add_to_history "Phi-3" "def main():"
                    add_to_history "Phi-3" "    print('Hola desde Distro-Ruth!')"
                    add_to_history "Phi-3" "    print('Este es un ejemplo de script creado con el asistente Phi-3')"
                    add_to_history "Phi-3" ""
                    add_to_history "Phi-3" "if __name__ == '__main__':"
                    add_to_history "Phi-3" "    main()"
                    add_to_history "Phi-3" "FIN_ARCHIVO"
                    
                    # Simular ejecución del comando
                    add_to_history "Phi-3" ""
                    add_to_history "Phi-3" "Para ejecutar este script, puedes usar:"
                    add_to_history "Phi-3" "EJECUTAR: python ejemplo.py"
                    
                    # Simular proceso de comandos
                    manage_file "ejemplo.py" "#!/usr/bin/env python3\ndef main():\n    print('Hola desde Distro-Ruth!')\n    print('Este es un ejemplo de script creado con el asistente Phi-3')\n\nif __name__ == '__main__':\n    main()"
                    add_to_history "Sistema" "Ejecutando: python ejemplo.py"
                    add_to_history "Sistema" "Resultado:"
                    add_to_history "Sistema" "  Hola desde Distro-Ruth!"
                    add_to_history "Sistema" "  Este es un ejemplo de script creado con el asistente Phi-3"
                    
                elif [[ "$user_input" == *"abre"* && "$user_input" == *"editor"* ]] ||
                     [[ "$user_input" == *"edita"* && "$user_input" == *"archivo"* ]]; then
                    
                    # Simular apertura de IDE
                    add_to_history "Phi-3" "Puedo abrir un editor para ti:"
                    add_to_history "Phi-3" "IDE: vscode-web ejemplo.py"
                    
                    # Simular proceso
                    open_ide "vscode-web" "ejemplo.py"
                    
                elif [[ "$user_input" == *"instala"* ]]; then
                    
                    # Simular instalación de paquetes
                    add_to_history "Phi-3" "Puedo instalar paquetes para ti:"
                    add_to_history "Phi-3" "INSTALAR: python requests numpy"
                    
                    # Simular proceso
                    install_packages "python" "requests" "numpy"
                    
                else
                    # Respuesta genérica
                    add_to_history "Phi-3" "Esta es una respuesta simulada. En un entorno real, recibirías una respuesta más personalizada del modelo Phi-3 Mini."
                    add_to_history "Phi-3" "Puedo ayudarte a:"
                    add_to_history "Phi-3" "- Crear y editar archivos (ARCHIVO: ruta)"
                    add_to_history "Phi-3" "- Ejecutar comandos (EJECUTAR: comando)"
                    add_to_history "Phi-3" "- Abrir editores (IDE: tipo ruta)"
                    add_to_history "Phi-3" "- Instalar paquetes (INSTALAR: tipo paquetes)"
                fi
                
                draw_ui
            fi
        done
    else
        # Verificar si el modelo y el ejecutable existen
        if [ ! -f "$MODEL_PATH" ] || [ ! -f "$EXEC_PATH" ]; then
            show_banner
            echo -e "${YELLOW}No se encontró el modelo Phi-3 o el ejecutable llama.cpp.${RESET}"
            echo -e "${BLUE}¿Deseas instalarlo ahora? (s/n)${RESET}"
            read -r response
            
            if [[ "$response" == "s" || "$response" == "S" ]]; then
                if [ -f "$SCRIPT_DIR/distro-setup-phi3.sh" ]; then
                    "$SCRIPT_DIR/distro-setup-phi3.sh"
                    # Verificar si la instalación fue exitosa
                    if [ -f "$MODEL_PATH" ] && [ -f "$EXEC_PATH" ]; then
                        interactive_chat
                    else
                        show_banner
                        echo -e "${RED}La instalación no se completó correctamente.${RESET}"
                        echo -e "${BLUE}Por favor, intenta instalar manualmente.${RESET}"
                        read -p "Presiona Enter para volver..."
                    fi
                else
                    show_banner
                    echo -e "${RED}No se encontró el script de instalación.${RESET}"
                    read -p "Presiona Enter para volver..."
                fi
            fi
        else
            # Ejecutar chat interactivo
            interactive_chat
        fi
    fi
}

# Ejecutar la función principal
main