#!/bin/bash
# Demostración para Termux Android de la distro con tema DraculaX

# Colores para la demostración
CYAN='\033[1;36m'
GREEN='\033[1;32m'
PURPLE='\033[1;35m'
PINK='\033[1;38;5;212m'
BLUE='\033[1;34m'
YELLOW='\033[1;33m'
WHITE='\033[1;37m'
NC='\033[0m'

# Limpiar pantalla y mostrar banner
clear
echo -e "${PURPLE}==================================================${NC}"
echo -e "${PINK}    Distro-Ruth - Ninja Shadow Edition    ${NC}"
echo -e "${PURPLE}==================================================${NC}"
echo -e "${CYAN}Esta es una muestra de cómo se vería la distribución${NC}"
echo -e "${CYAN}en un dispositivo Android con Termux${NC}"
echo

# Simular comandos
echo -e "${PURPLE}termux${PINK}@android${NC}:${BLUE}~${NC}${GREEN}\$ ${WHITE}cd distro-ruth${NC}"
sleep 1
echo -e "${PURPLE}termux${PINK}@android${NC}:${BLUE}~/distro-ruth${NC}${GREEN}\$ ${WHITE}./start.sh${NC}"
sleep 1

# Banner de la distro
echo -e "${PURPLE}==================================================${NC}"
echo -e "${PINK}Distro-Ruth - Ninja Shadow Edition${NC}"
echo -e "${PURPLE}==================================================${NC}"
echo -e "${CYAN}This is a simulated environment running on Termux${NC}"
echo -e "${CYAN}with Ninja theme and Shadow background.${NC}"
echo
echo -e "${GREEN}Comandos disponibles:${NC}"
echo -e "${PURPLE}  • ${CYAN}nano ${WHITE}- Editor de texto simple${NC}"
echo -e "${PURPLE}  • ${CYAN}vscode-web ${WHITE}- IDE Visual Studio Code${NC}"
echo -e "${PURPLE}  • ${CYAN}arduino-web ${WHITE}- IDE para Arduino${NC}"
echo -e "${PURPLE}  • ${CYAN}ai-assistant ${WHITE}- Asistente de programación IA${NC}"
echo -e "${PURPLE}  • ${CYAN}ollama-agent ${WHITE}- Asistente de código con Ollama${NC}"
echo -e "${PURPLE}  • ${CYAN}phi3-agent ${WHITE}- Asistente con modelo Phi-3 Mini${NC}"
echo -e "${PURPLE}  • ${CYAN}ruth-help ${WHITE}- Guía completa de comandos${NC}"
echo -e "${PURPLE}==================================================${NC}"
echo

# Mostrar el prompt
echo -e "${PURPLE}ninja${PINK}@distro-ruth${NC}:${BLUE}~${NC}${GREEN}\$ ${WHITE}_${NC}"

# Mensaje final
echo
echo -e "${YELLOW}La distribución completa incluye:${NC}"
echo -e "  ${WHITE}• ${CYAN}Sistema de persistencia para guardar archivos${NC}"
echo -e "  ${WHITE}• ${CYAN}Herramientas de desarrollo simuladas${NC}"
echo -e "  ${WHITE}• ${CYAN}Asistentes de IA (OpenAI, Anthropic, Phi-3, Ollama)${NC}"
echo -e "  ${WHITE}• ${CYAN}Documentación completa con comando ruth-help${NC}"
echo -e "  ${WHITE}• ${CYAN}Compatibilidad con Termux Android${NC}"
echo
echo -e "${YELLOW}Para instalar la distribución completa en Termux:${NC}"
echo -e "${WHITE}1. ${CYAN}Descarga los archivos del repositorio${NC}"
echo -e "${WHITE}2. ${CYAN}Ejecuta: ${GREEN}chmod +x termux-setup.sh${NC}"
echo -e "${WHITE}3. ${CYAN}Ejecuta: ${GREEN}./termux-setup.sh${NC}"
echo
echo -e "${PURPLE}==================================================${NC}"