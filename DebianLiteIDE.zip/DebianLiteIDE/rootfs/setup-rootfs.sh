#!/bin/bash
# Setup script for rootfs environment

# Create simulated user environment
echo "Setting up simulated user environment..."

# Create directories for development tools
mkdir -p /opt/vscode
mkdir -p /opt/arduino
mkdir -p /usr/local/bin

# Create directories for AI assistant
mkdir -p /opt/ai-assistant

# Create script directories
mkdir -p /usr/local/scripts

# Create a simulated sudo command
cat > /bin/sudo << 'EOF'
#!/bin/bash
# Simulated sudo command - just runs the command
exec "$@"
EOF
chmod +x /bin/sudo

# Create a simulated user account
mkdir -p /home/developer
echo "developer:x:1000:1000:Developer,,,:/home/developer:/bin/bash" >> /etc/passwd
echo "developer:x:1000:" >> /etc/group
echo "sudo:x:27:developer" >> /etc/group
echo "export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin" > /home/developer/.bashrc
echo "export PS1='developer@debian-proot:\w\$ '" >> /home/developer/.bashrc
chown -R 1000:1000 /home/developer

echo "Rootfs basic setup completed."
