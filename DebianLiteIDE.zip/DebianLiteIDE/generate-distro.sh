
#!/bin/bash

DISTRO_NAME="ruth-debian"
DISTRO_VERSION="1.0"
ARCH="$(uname -m)"
DATE="$(date +%Y%m%d)"
OUTPUT_DIR="./dist"
ROOTFS_DIR="./rootfs"

# Crear directorio de salida
mkdir -p "${OUTPUT_DIR}"

# Generar el paquete
echo "Generando paquete de distribución..."
tar -cJf "${OUTPUT_DIR}/${DISTRO_NAME}-${DISTRO_VERSION}-${ARCH}-${DATE}.tar.xz" \
    --exclude='*.git' \
    --exclude='*.tar.xz' \
    --exclude='dist' \
    "${ROOTFS_DIR}"

echo "Paquete generado en: ${OUTPUT_DIR}/${DISTRO_NAME}-${DISTRO_VERSION}-${ARCH}-${DATE}.tar.xz"
