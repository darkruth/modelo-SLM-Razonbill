
#!/bin/bash

# Colores
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

echo "=== Verificación del Sistema Ruth ==="

# Verificar kernel
echo -e "\n${GREEN}>>> Información del Kernel:${NC}"
uname -a

# Verificar APT
echo -e "\n${GREEN}>>> Verificando APT:${NC}"
if command -v apt &> /dev/null; then
    echo "APT está instalado"
    apt update
else
    echo -e "${RED}APT no está instalado${NC}"
fi

# Verificar gestores de paquetes
echo -e "\n${GREEN}>>> Verificando gestores de paquetes:${NC}"
for pkg in apt apt-get aptitude; do
    if command -v $pkg &> /dev/null; then
        echo "$pkg está instalado"
    else
        echo -e "${RED}$pkg no está instalado${NC}"
    fi
done

# Verificar comandos esenciales
echo -e "\n${GREEN}>>> Verificando comandos esenciales:${NC}"
for cmd in sudo su passwd chmod git curl; do
    if command -v $cmd &> /dev/null; then
        echo "$cmd está disponible"
    else
        echo -e "${RED}$cmd no está disponible${NC}"
    fi
done

# Verificar permisos de sudo
echo -e "\n${GREEN}>>> Verificando permisos de sudo:${NC}"
sudo -n true 2>/dev/null && echo "Sudo está configurado correctamente" || echo -e "${RED}Sudo requiere configuración${NC}"
