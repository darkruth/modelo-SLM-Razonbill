
#!/data/data/com.termux/files/usr/bin/bash

# Arquitecturas soportadas
DISTRO_ARCH="$(uname -m)"

# Nombre y descripción de la distribución
DISTRO_NAME="ruth-debian"
DISTRO_COMMENT="Ruth Debian minimal distribution with AI assistant"

# Configuración del tarball
TARBALL_STRIP_OPT=1

# URLs para diferentes arquitecturas usando rutas locales
TARBALL_URL['aarch64']="file:///data/data/com.termux/files/home/ruth-debian/dist/ruth-debian-1.0-aarch64-$(date +%Y%m%d).tar.xz"
TARBALL_URL['arm']="file:///data/data/com.termux/files/home/ruth-debian/dist/ruth-debian-1.0-arm-$(date +%Y%m%d).tar.xz"
TARBALL_URL['x86_64']="file:///data/data/com.termux/files/home/ruth-debian/dist/ruth-debian-1.0-x86_64-$(date +%Y%m%d).tar.xz"

# Función de configuración que se ejecuta durante la instalación
distro_setup() {
    # Configurar entorno básico
    run_proot_cmd bash /setup.sh
    
    # Configurar persistencia
    run_proot_cmd bash /persistence.sh restore
    
    # Asegurar permisos correctos
    run_proot_cmd chmod +x /usr/local/bin/ruth-help
    run_proot_cmd chmod +x /opt/ai-assistant/phi3-agent
    run_proot_cmd chmod +x /opt/ai-assistant/ollama-agent
    
    # Crear enlace simbólico para ruth-help si no existe
    run_proot_cmd ln -sf /usr/local/bin/ruth-help /bin/ruth-help
}
