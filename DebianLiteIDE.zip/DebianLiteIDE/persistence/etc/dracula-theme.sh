#!/bin/bash
# DraculaX theme with Xeon background for CLI

# Colores Dracula
export COLOR_BLACK="#282a36"
export COLOR_RED="#ff5555"
export COLOR_GREEN="#50fa7b"
export COLOR_YELLOW="#f1fa8c"
export COLOR_BLUE="#bd93f9"
export COLOR_MAGENTA="#ff79c6"
export COLOR_CYAN="#8be9fd"
export COLOR_WHITE="#f8f8f2"
export COLOR_BRIGHT_BLACK="#6272a4"
export COLOR_XEON_BG="#0a0e14"

# Configuración de colores para PS1
export PS1_COLOR_USER="\[\033[38;5;141m\]"  # Púrpura claro (similar a #bd93f9)
export PS1_COLOR_HOST="\[\033[38;5;212m\]"  # Rosa claro (similar a #ff79c6)
export PS1_COLOR_PATH="\[\033[38;5;117m\]"  # Azul claro (similar a #8be9fd)
export PS1_COLOR_PROMPT="\[\033[38;5;84m\]"  # Verde claro (similar a #50fa7b)
export PS1_COLOR_RESET="\[\033[0m\]"

# Configuración LS_COLORS estilo Dracula
export LS_COLORS="di=1;34:ln=1;35:so=1;32:pi=1;33:ex=1;31:bd=34;46:cd=34;43:su=30;41:sg=30;46:tw=30;42:ow=30;43"

# Alias para mejorar la experiencia visual
alias ls='ls --color=auto'
alias grep='grep --color=auto'
alias diff='diff --color=auto'