#!/bin/bash
# Script de demostración para mostrar la interfaz DraculaX

echo "=========================================================="
echo "            DEMOSTRACIÓN DE LA DISTRIBUCIÓN CLI           "
echo "         CON TEMA DRACULAX Y FONDO XEON ACTIVADO          "
echo "=========================================================="
echo

# Colores para la demostración
CYAN='\033[1;36m'
GREEN='\033[1;32m'
PURPLE='\033[1;35m'
PINK='\033[1;38;5;212m'
BLUE='\033[1;34m'
YELLOW='\033[1;33m'
WHITE='\033[1;37m'
NC='\033[0m'

# Función para simular un comando (versión rápida sin animación)
simulate_command() {
    command=$1
    output=$2
    
    echo -e "${PURPLE}debian${PINK}@draculax${NC}:${BLUE}~${NC}${GREEN}\$ ${NC}$command" 
    echo -e "$output"
    echo
}

# Banner inicial
echo -e "${PURPLE}=================================================${NC}"
echo -e "${PINK}Minimal Debian CLI Environment - DraculaX Theme${NC}"
echo -e "${PURPLE}=================================================${NC}"
echo -e "${CYAN}This is a simulated environment designed to work"
echo -e "within Replit's limitations.${NC}"
echo
echo -e "${GREEN}Available commands:${NC}"
echo -e "${PURPLE}  1. ${CYAN}nano${NC} - simple text editor"
echo -e "${PURPLE}  2. ${CYAN}vscode-web${NC} - start VSCode web IDE"
echo -e "${PURPLE}  3. ${CYAN}arduino-web${NC} - start Arduino web IDE"
echo -e "${PURPLE}  4. ${CYAN}ai-assistant${NC} - start AI programming assistant"
echo -e "${PURPLE}  5. ${CYAN}exit${NC} - exit this environment"
echo -e "${PURPLE}=================================================${NC}"
echo

# Demostración de comandos básicos
sleep 1
simulate_command "help" "$(cat << 'EOF'
[38;5;141m┌───────────────────────────────────────────────────────┐[0m
[38;5;141m│[38;5;212m          Comandos disponibles - DraculaX Theme         [38;5;141m│[0m
[38;5;141m├───────────────────────┬───────────────────────────────┤[0m
[38;5;141m│[38;5;117m  Herramientas        [38;5;141m│[38;5;189m Comandos del sistema          [38;5;141m│[0m
[38;5;141m├───────────────────────┼───────────────────────────────┤[0m
[38;5;141m│[38;5;84m  nano                [38;5;141m│[38;5;189m Editor de texto simple        [38;5;141m│[0m
[38;5;141m│[38;5;84m  vscode-web          [38;5;141m│[38;5;189m IDE Visual Studio Code       [38;5;141m│[0m
[38;5;141m│[38;5;84m  arduino-web         [38;5;141m│[38;5;189m IDE para Arduino             [38;5;141m│[0m
[38;5;141m│[38;5;84m  ai-assistant        [38;5;141m│[38;5;189m Asistente de programación IA [38;5;141m│[0m
[38;5;141m├───────────────────────┼───────────────────────────────┤[0m
[38;5;141m│[38;5;117m  Sistema             [38;5;141m│[38;5;189m                              [38;5;141m│[0m
[38;5;141m├───────────────────────┼───────────────────────────────┤[0m
[38;5;141m│[38;5;84m  ls                  [38;5;141m│[38;5;189m Listar archivos              [38;5;141m│[0m
[38;5;141m│[38;5;84m  cd                  [38;5;141m│[38;5;189m Cambiar directorio           [38;5;141m│[0m
[38;5;141m│[38;5;84m  pwd                 [38;5;141m│[38;5;189m Mostrar directorio actual    [38;5;141m│[0m
[38;5;141m│[38;5;84m  cat                 [38;5;141m│[38;5;189m Mostrar contenido de archivo [38;5;141m│[0m
[38;5;141m│[38;5;84m  help                [38;5;141m│[38;5;189m Mostrar esta ayuda           [38;5;141m│[0m
[38;5;141m│[38;5;84m  exit                [38;5;141m│[38;5;189m Salir del entorno            [38;5;141m│[0m
[38;5;141m└───────────────────────┴───────────────────────────────┘[0m
EOF
)"

# Comando ls
simulate_command "ls" "[38;5;141mbin  [38;5;117mdev  [38;5;212metc  [38;5;141mhome  [38;5;117mlib64  [38;5;212mopt  [38;5;141mproc  [38;5;117mroot  [38;5;212msbin  [38;5;141msys  [38;5;117mtmp  [38;5;212musr  [38;5;141mvar[0m"

# Comando pwd
simulate_command "pwd" "[38;5;212m/root[0m"

# Comando cat
simulate_command "cat /etc/passwd" "$(cat << 'EOF'
[38;5;141m┌───────────────────────────────────────────┐[0m
[38;5;141m│[38;5;189m  Contenido simulado del archivo: [38;5;212m/etc/passwd  [38;5;141m│[0m
[38;5;141m│[38;5;189m  En un entorno real, verías el contenido    [38;5;141m│[0m
[38;5;141m│[38;5;189m  del archivo con resaltado de sintaxis.     [38;5;141m│[0m
[38;5;141m└───────────────────────────────────────────┘[0m
EOF
)"

# Demostración de nano
echo -e "${PURPLE}debian${PINK}@draculax${NC}:${BLUE}~${NC}${GREEN}\$ ${NC}nano" 
echo -e "$(cat << 'EOF'
[38;5;141m=================================[0m
[38;5;117mNano Editor - DraculaX Theme[0m
[38;5;141m=================================[0m

[38;5;84mSimulated nano editor[0m
[38;5;189mThis is a placeholder for the real nano editor[0m
[38;5;212mPress Ctrl+C to exit[0m

[38;5;141m┌───────────────────────────────────────────┐[0m
[38;5;141m│[38;5;189m  In a real environment, you would see     [38;5;141m│[0m
[38;5;141m│[38;5;189m  a text editor with syntax highlighting.  [38;5;141m│[0m
[38;5;141m│[38;5;189m                                           [38;5;141m│[0m
[38;5;141m│[38;5;189m  The DraculaX theme would provide:        [38;5;141m│[0m
[38;5;141m│[38;5;189m  - Dark background with vibrant colors    [38;5;141m│[0m
[38;5;141m│[38;5;189m  - Improved readability for code          [38;5;141m│[0m
[38;5;141m│[38;5;189m  - Special highlighting for syntax        [38;5;141m│[0m
[38;5;141m└───────────────────────────────────────────┘[0m

[38;5;212mCommands: ^G Get Help  ^O Write Out  ^W Where Is  ^K Cut Text[0m
[38;5;212m         ^X Exit      ^J Justify    ^R Read File ^U Paste  [0m

[38;5;84mPresionando Enter para volver al shell...[0m
EOF
)"
echo
sleep 2

# Demostración del asistente IA
echo -e "${PURPLE}debian${PINK}@draculax${NC}:${BLUE}~${NC}${GREEN}\$ ${NC}ai-assistant" 
echo -e "$(cat << 'EOF'
[38;5;141m=================================[0m
[38;5;212mAI Programming Assistant[0m
[38;5;141m=================================[0m

[38;5;189mType your questions below and press Enter to send.[0m
[38;5;189mType '[38;5;212mexit[38;5;189m' to quit the assistant.[0m

[38;5;84mYou: [38;5;189m¿Cómo puedo crear un bucle for en Python?

[38;5;141mAI: [38;5;189mEn Python, puedes crear un bucle for de varias maneras:

1. Iterar sobre una secuencia de números:
   ```python
   for i in range(5):  # 0, 1, 2, 3, 4
       print(i)
   ```

2. Iterar sobre una lista:
   ```python
   frutas = ["manzana", "banana", "cereza"]
   for fruta in frutas:
       print(fruta)
   ```

3. Iterar sobre un diccionario:
   ```python
   persona = {"nombre": "Juan", "edad": 30}
   for clave, valor in persona.items():
       print(f"{clave}: {valor}")
   ```

4. Bucle for con índice y valor usando enumerate:
   ```python
   for indice, valor in enumerate(frutas):
       print(f"Índice {indice}: {valor}")
   ```

Estos son ejemplos básicos. ¿Necesitas algo más específico?

[38;5;84mYou: [38;5;189mexit

[38;5;212mGoodbye![0m
EOF
)"
echo
sleep 2

# Salir del entorno
echo -e "${PURPLE}debian${PINK}@draculax${NC}:${BLUE}~${NC}${GREEN}\$ ${NC}exit" 
echo -e "${CYAN}Realizando backup antes de salir...[0m"
echo -e "${CYAN}Backup completado en ./persistence[0m"
echo -e "${PINK}Saliendo del entorno Debian CLI...[0m"
echo

echo "=========================================================="
echo "               FIN DE LA DEMOSTRACIÓN                     "
echo "=========================================================="