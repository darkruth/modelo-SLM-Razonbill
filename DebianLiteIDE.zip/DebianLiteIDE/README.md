
# 🥷 Distro-Ruth - Ninja Shadow Edition

Una distribución Linux minimalista con tema ninja, asistente IA y herramientas de desarrollo integradas.

![Ninja Theme](generated-icon.png)

## 🌟 Características Principales

- 🎭 **Tema Ninja con Sombras**: Interfaz elegante con animaciones y tema oscuro
- 🤖 **Asistente IA Integrado**: Múltiples agentes de IA para programación
  - OpenAI GPT Agent
  - Phi-3 Local Agent
  - Ollama Integration
- 🛠️ **Herramientas de Desarrollo**:
  - VSCode Web IDE
  - Arduino Web IDE
  - Editor Nano
- 💾 **Sistema de Persistencia**: Guarda configuraciones entre sesiones
- 📱 **Compatible**: Funciona en Replit y Termux Android

## 📥 Instalación

### En Replit:

1. Clonar el repositorio:
```bash
git clone <repo-url>
cd distro-ruth
```

2. Ejecutar setup:
```bash
chmod +x setup.sh
./setup.sh
```

3. Iniciar el entorno:
```bash
./start.sh
```

### En Termux (Android):

1. Instalar proot-distro:
```bash
pkg install proot-distro
```

2. Instalar Ruth desde archivo tar.xz:
```bash
proot-distro install ruth-debian --tar ruth-debian-1.0-aarch64.tar.xz
```

3. Iniciar Ruth:
```bash
proot-distro login ruth-debian
```

## 🤖 Configuración del Asistente IA

### OpenAI Agent:

```bash
ai-assistant --set-key TU_API_KEY
```

### Phi-3 Local Agent:

1. Preparar modelo:
```bash
phi3-setup download
phi3-setup prepare
```

2. Iniciar agente:
```bash
phi3-agent start
```

### Ollama Integration:

```bash
ollama-agent setup
ollama-agent pull codellama
```

## 📚 Comandos Principales

- `ruth-help`: Muestra ayuda y comandos disponibles
- `ai-assistant`: Inicia el asistente IA principal
- `phi3-agent`: Inicia el agente local Phi-3
- `ollama-agent`: Gestiona la integración con Ollama
- `vscode-web`: Abre VSCode Web IDE
- `arduino-web`: Abre Arduino Web IDE

## 🔧 Scripts Principales

- `setup.sh`: Configura el entorno inicial
- `start.sh`: Inicia la distribución
- `persistence.sh`: Gestiona la persistencia de datos
- `verify-system.sh`: Verifica la integridad del sistema
- `generate-distro.sh`: Genera el archivo tar.xz de la distribución

## 💡 Posibles Mejoras

1. **Extensiones del Asistente IA**:
   - Soporte para más modelos locales
   - Mejora del entrenamiento específico para tareas
   - Integración con otros LLMs

2. **Optimizaciones del Sistema**:
   - Reducción del tamaño base
   - Mejora del rendimiento en dispositivos limitados
   - Soporte para más arquitecturas

3. **Nuevas Características**:
   - Interfaz web para gestión
   - Más herramientas de desarrollo
   - Sistema de plugins

## 📋 Notas de Uso

- La funcionalidad del asistente IA varía según el entorno y configuración
- Se recomienda usar una conexión estable para la descarga de modelos
- Los modelos locales requieren recursos significativos

## 🤝 Contribución

Las contribuciones son bienvenidas. Áreas principales de mejora:
- Optimización de modelos IA
- Nuevas herramientas de desarrollo
- Mejoras en la interfaz de usuario
- Documentación y ejemplos

## 📄 Licencia

Este proyecto está bajo la Licencia MIT. Ver el archivo `LICENSE` para más detalles.
