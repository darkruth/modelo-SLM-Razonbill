#!/bin/bash
# Animación de inicio con sombra de ninja chino con sombrero abriendo y cerrando katana
# Diseñado para ocupar aproximadamente 20% del display en smartphone

# Colores del tema DraculaX
PURPLE='\033[38;5;141m'
PINK='\033[38;5;212m'
BLUE='\033[38;5;117m'
GREEN='\033[38;5;84m'
YELLOW='\033[38;5;228m'
CYAN='\033[38;5;159m'
WHITE='\033[38;5;255m'
ORANGE='\033[38;5;215m'
RED='\033[38;5;203m'
BLACK='\033[38;5;0m'
DARK_GRAY='\033[38;5;240m'
GRAY='\033[38;5;245m'
NC='\033[0m'

# Función para limpiar la pantalla y posicionar el cursor
clear_screen() {
    clear
    # Mover cursor a la parte superior
    echo -e "\033[H"
}

# Calcular dimensiones de la pantalla
get_terminal_size() {
    if [ -z "$COLUMNS" ] || [ -z "$LINES" ]; then
        if command -v tput >/dev/null 2>&1; then
            COLUMNS=$(tput cols)
            LINES=$(tput lines)
        elif command -v stty >/dev/null 2>&1; then
            TERM_SIZE=$(stty size 2>/dev/null || echo "24 80")
            LINES=$(echo "$TERM_SIZE" | cut -d ' ' -f 1)
            COLUMNS=$(echo "$TERM_SIZE" | cut -d ' ' -f 2)
        else
            COLUMNS=80
            LINES=24
        fi
    fi
}

# Función para calcular el centro de la pantalla
get_center_position() {
    local width=$1
    local height=$2
    
    # Calcular posición
    CENTER_X=$(( (COLUMNS - width) / 2 ))
    CENTER_Y=$(( (LINES - height) / 2 ))
    
    # Asegurar que no sea menor a 0
    [ $CENTER_X -lt 0 ] && CENTER_X=0
    [ $CENTER_Y -lt 0 ] && CENTER_Y=0
}

# Posicionar cursor en coordenadas específicas
position_cursor() {
    local x=$1
    local y=$2
    echo -ne "\033[${y};${x}H"
}

# Crear el marco para la animación
draw_frame() {
    local width=50  # Ancho del marco
    local height=15 # Alto del marco
    
    get_center_position $width $height
    
    # Dibujar borde superior
    position_cursor $CENTER_X $CENTER_Y
    echo -ne "${PURPLE}╔"
    for ((i=1; i<width-1; i++)); do
        echo -ne "═"
    done
    echo -e "╗${NC}"
    
    # Dibujar lados
    for ((i=1; i<height-1; i++)); do
        position_cursor $CENTER_X $((CENTER_Y + i))
        echo -ne "${PURPLE}║${NC}"
        position_cursor $((CENTER_X + width - 1)) $((CENTER_Y + i))
        echo -ne "${PURPLE}║${NC}"
    done
    
    # Dibujar borde inferior
    position_cursor $CENTER_X $((CENTER_Y + height - 1))
    echo -ne "${PURPLE}╚"
    for ((i=1; i<width-1; i++)); do
        echo -ne "═"
    done
    echo -e "╝${NC}"
    
    # Dibujar título "Distro-Ruth" con contorno neón morado oscuro
    position_cursor $((CENTER_X + (width - 12) / 2)) $((CENTER_Y - 1))
    
    # Primera línea del título con efecto de contorno neón
    echo -e "${PURPLE}  ▄▄▄▄▄▄▄▄▄▄▄  ${NC}"
    
    # Segunda línea del título con letras negras y contorno neón
    position_cursor $((CENTER_X + (width - 12) / 2)) $((CENTER_Y))
    echo -e "${PURPLE}▐█${BLACK}Distro-Ruth${PURPLE}█▌${NC}"
    
    # Tercera línea del título con efecto de contorno neón
    position_cursor $((CENTER_X + (width - 12) / 2)) $((CENTER_Y + 1))
    echo -e "${PURPLE}  ▀▀▀▀▀▀▀▀▀▀▀  ${NC}"
}

# Frames de la animación del ninja
frame1() {
    local x=$1
    local y=$2
    
    # Sombra del ninja con katana cerrada (frame 1)
    position_cursor $x $y
    echo -e "${DARK_GRAY}      .--.      ${NC}"
    position_cursor $x $((y+1))
    echo -e "${DARK_GRAY}     /    \\     ${NC}"
    position_cursor $x $((y+2))
    echo -e "${DARK_GRAY}    |  ..  |    ${NC}"
    position_cursor $x $((y+3))
    echo -e "${DARK_GRAY}     \\____/     ${NC}"
    position_cursor $x $((y+4))
    echo -e "${DARK_GRAY}       ||       ${NC}"
    position_cursor $x $((y+5))
    echo -e "${DARK_GRAY}    .-/||\\.     ${NC}"
    position_cursor $x $((y+6))
    echo -e "${DARK_GRAY}   /  /||\\  \\   ${NC}"
    position_cursor $x $((y+7))
    echo -e "${DARK_GRAY}      /  \\      ${NC}"
    position_cursor $x $((y+8))
    echo -e "${DARK_GRAY}     /    \\     ${NC}"
}

frame2() {
    local x=$1
    local y=$2
    
    # Sombra del ninja con katana preparándose (frame 2)
    position_cursor $x $y
    echo -e "${DARK_GRAY}      .--.      ${NC}"
    position_cursor $x $((y+1))
    echo -e "${DARK_GRAY}     /    \\     ${NC}"
    position_cursor $x $((y+2))
    echo -e "${DARK_GRAY}    |  ..  |    ${NC}"
    position_cursor $x $((y+3))
    echo -e "${DARK_GRAY}     \\____/     ${NC}"
    position_cursor $x $((y+4))
    echo -e "${DARK_GRAY}       ||       ${NC}"
    position_cursor $x $((y+5))
    echo -e "${DARK_GRAY}    .-/||\\.     ${NC}"
    position_cursor $x $((y+6))
    echo -e "${DARK_GRAY}   /.-/||\\-.\\   ${NC}"
    position_cursor $x $((y+7))
    echo -e "${DARK_GRAY}      /  \\      ${NC}"
    position_cursor $x $((y+8))
    echo -e "${DARK_GRAY}     /    \\     ${NC}"
}

frame3() {
    local x=$1
    local y=$2
    
    # Sombra del ninja con katana abierta (frame 3)
    position_cursor $x $y
    echo -e "${DARK_GRAY}      .--.      ${NC}"
    position_cursor $x $((y+1))
    echo -e "${DARK_GRAY}     /    \\     ${NC}"
    position_cursor $x $((y+2))
    echo -e "${DARK_GRAY}    |  ..  |    ${NC}"
    position_cursor $x $((y+3))
    echo -e "${DARK_GRAY}     \\____/     ${NC}"
    position_cursor $x $((y+4))
    echo -e "${DARK_GRAY}       ||       ${NC}"
    position_cursor $x $((y+5))
    echo -e "${DARK_GRAY}    .-/||\\.     ${NC}"
    position_cursor $x $((y+6))
    echo -e "${DARK_GRAY}  --.-/||\\-.--  ${NC}"
    position_cursor $x $((y+7))
    echo -e "${DARK_GRAY}      /  \\      ${NC}"
    position_cursor $x $((y+8))
    echo -e "${DARK_GRAY}     /    \\     ${NC}"
}

# Animación principal
animate_ninja() {
    # Obtener dimensiones de terminal
    get_terminal_size
    
    # Dibujar marco
    draw_frame
    
    # Calcular posición para el ninja (centrado dentro del marco)
    local ninja_width=16
    local ninja_height=9
    local frame_width=50
    local frame_height=15
    
    get_center_position $frame_width $frame_height
    
    # Posición del ninja dentro del marco
    NINJA_X=$((CENTER_X + (frame_width - ninja_width) / 2))
    NINJA_Y=$((CENTER_Y + 3))  # Ajustado para centrar verticalmente
    
    # Animación de apertura y cierre de katana
    for ((i=0; i<6; i++)); do
        # Frame 1: Katana cerrada
        frame1 $NINJA_X $NINJA_Y
        sleep 0.3
        
        # Frame 2: Preparando katana
        frame2 $NINJA_X $NINJA_Y
        sleep 0.2
        
        # Frame 3: Katana abierta
        frame3 $NINJA_X $NINJA_Y
        sleep 0.4
        
        # Frame 2: Recogiendo katana
        frame2 $NINJA_X $NINJA_Y
        sleep 0.2
    done
    
    # Mensaje de bienvenida
    position_cursor $((CENTER_X + 5)) $((CENTER_Y + frame_height))
    echo -e "${CYAN}Iniciando Distro-Ruth Environment...${NC}"
    sleep 1
    
    # Limpiar pantalla para continuar
    sleep 0.5
    clear_screen
}

# Iniciar animación
clear_screen
animate_ninja

# Volver a la posición normal para continuar con el script de inicio
echo -e "\n\n"