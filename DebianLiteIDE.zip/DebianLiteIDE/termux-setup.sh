#!/data/data/com.termux/files/usr/bin/bash
# Script para instalar y ejecutar la distro en Termux Android

# Colores para output
CYAN='\033[1;36m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
RED='\033[1;31m'
NC='\033[0m' # No Color

echo -e "${CYAN}==============================================${NC}"
echo -e "${GREEN}Instalador para Termux Android${NC}"
echo -e "${CYAN}==============================================${NC}"

# Comprobar si estamos en Termux
if [ ! -d "/data/data/com.termux" ]; then
    echo -e "${RED}Error: Este script debe ejecutarse en Termux Android.${NC}"
    exit 1
fi

# Comprobar si proot está instalado
if ! command -v proot &> /dev/null; then
    echo -e "${YELLOW}Instalando proot...${NC}"
    pkg update -y
    pkg install -y proot
fi

# Comprobar si wget está instalado
if ! command -v wget &> /dev/null; then
    echo -e "${YELLOW}Instalando wget...${NC}"
    pkg install -y wget
fi

# Definir directorios
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TERMUX_FILES="/data/data/com.termux/files"
TERMUX_HOME="$TERMUX_FILES/home"

# Crear script wrapper para iniciar el entorno
create_wrapper() {
    # Crear wrapper para iniciar la distro
    cat > "$TERMUX_HOME/debian-cli" << EOF
#!/data/data/com.termux/files/usr/bin/bash
cd "$SCRIPT_DIR"
./start.sh
EOF
    chmod +x "$TERMUX_HOME/debian-cli"
    
    # Crear enlace simbólico para ruth-help
    if [ -f "$SCRIPT_DIR/ruth-help" ]; then
        cat > "$TERMUX_HOME/ruth-help" << EOF
#!/data/data/com.termux/files/usr/bin/bash
cd "$SCRIPT_DIR"
./ruth-help
EOF
        chmod +x "$TERMUX_HOME/ruth-help"
        echo -e "${GREEN}Comando ruth-help instalado correctamente.${NC}"
    fi
    
    echo -e "${GREEN}Se ha creado un wrapper para iniciar la distro.${NC}"
    echo -e "${YELLOW}Ejecuta 'debian-cli' para iniciar el entorno.${NC}"
    echo -e "${YELLOW}Usa 'ruth-help' para ver la documentación completa.${NC}"
}

# Función para ejecutar la configuración inicial
setup_environment() {
    echo -e "${YELLOW}Configurando el entorno...${NC}"
    
    # Ejecutar el script de configuración
    cd "$SCRIPT_DIR"
    chmod +x setup.sh
    ./setup.sh
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}Configuración completada con éxito.${NC}"
        
        # Verificar y configurar manualmente ruth-help si es necesario
        if [ -f "./ruth-help.txt" ] && [ -f "./ruth-help" ]; then
            echo -e "${GREEN}Configurando comando ruth-help para Termux...${NC}"
            chmod +x ./ruth-help
            cp -f ./ruth-help "$TERMUX_HOME/" 2>/dev/null || true
            mkdir -p "$TERMUX_FILES/usr/local/bin/" 2>/dev/null || true
            cp -f ./ruth-help "$TERMUX_FILES/usr/local/bin/" 2>/dev/null || true
        fi
        
        create_wrapper
    else
        echo -e "${RED}Error durante la configuración.${NC}"
        exit 1
    fi
}

# Función para ejecutar la distribución
run_environment() {
    echo -e "${YELLOW}Iniciando entorno...${NC}"
    cd "$SCRIPT_DIR"
    
    # Asegurar que los scripts tengan permisos de ejecución
    chmod +x start.sh
    chmod +x ruth-help 2>/dev/null || true
    
    # En Termux, necesitamos algunas variables de entorno específicas
    export PROOT_NO_SECCOMP=1
    export TERMUX_VERSION="Distro-Ruth-Android"
    
    # Iniciar la distro
    ./start.sh
}

# Menú de opciones
echo -e "${CYAN}Selecciona una opción:${NC}"
echo -e "${YELLOW}1. Instalar/Configurar el entorno${NC}"
echo -e "${YELLOW}2. Ejecutar el entorno${NC}"
echo -e "${YELLOW}3. Salir${NC}"
read -p "Opción: " option

case $option in
    1)
        setup_environment
        ;;
    2)
        run_environment
        ;;
    3)
        echo -e "${GREEN}Saliendo...${NC}"
        exit 0
        ;;
    *)
        echo -e "${RED}Opción no válida.${NC}"
        exit 1
        ;;
esac

exit 0